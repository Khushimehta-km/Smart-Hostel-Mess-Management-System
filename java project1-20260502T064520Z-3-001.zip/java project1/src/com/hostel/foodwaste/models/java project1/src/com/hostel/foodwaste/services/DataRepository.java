package com.hostel.foodwaste.services;

import java.sql.*;
import com.hostel.foodwaste.utils.DBConnection;
import com.hostel.foodwaste.models.DailyWasteRecord;
import com.hostel.foodwaste.models.SpecialMealRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Centralized Data Repository for the system.
 * Handles in-memory storage for waste records and special meal requests.
 */
public class DataRepository {
    private static DataRepository instance;
    private List<DailyWasteRecord> wasteRecords = new ArrayList<>();
    private List<SpecialMealRequest> specialMealRequests = new ArrayList<>();

    public DataRepository() {
    }

    public static DataRepository getInstance() {
        if (instance == null) {
            instance = new DataRepository();
        }
        return instance;
    }

    // Waste Records
    public void addWasteRecord(DailyWasteRecord record) {
        wasteRecords.add(record);
    }

    public void saveWasteData(String meal, int waste) {

        try {
            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO waste_records(date, meal_type, waste_qty) VALUES (CURDATE(), ?, ?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, meal);
            ps.setInt(2, waste);

            ps.executeUpdate();

            System.out.println("Data saved in DB ✅");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<DailyWasteRecord> getWasteRecords() {
        return new ArrayList<>(wasteRecords);
    }

    public DailyWasteRecord getRecordByDate(String date) {
        return wasteRecords.stream()
                .filter(r -> r.getDate().equals(date))
                .findFirst()
                .orElse(null);
    }

    // Special Meal Requests
    public void addSpecialMealRequest(SpecialMealRequest request) {
        specialMealRequests.add(request);
    }

    public List<SpecialMealRequest> getSpecialMealRequests() {
        return new ArrayList<>(specialMealRequests);
    }

    public List<SpecialMealRequest> getSpecialMealsByDate(String date) {
        return specialMealRequests.stream()
                .filter(r -> r.getRequestDate().equals(date))
                .collect(Collectors.toList());
    }

    // Analysis Helpers
    public double getTotalPrepared() {
        return wasteRecords.stream().mapToDouble(DailyWasteRecord::getPreparedKg).sum();
    }

    public double getTotalConsumed() {
        return wasteRecords.stream().mapToDouble(DailyWasteRecord::getConsumedKg).sum();
    }

    public double getTotalWasted() {
        return wasteRecords.stream().mapToDouble(DailyWasteRecord::getWastedKg).sum();
    }

    public int getTotalBookedStudents(String date) {
        DailyWasteRecord r = getRecordByDate(date);
        return (r != null) ? r.getBookedStudents() : 0;
    }
}
