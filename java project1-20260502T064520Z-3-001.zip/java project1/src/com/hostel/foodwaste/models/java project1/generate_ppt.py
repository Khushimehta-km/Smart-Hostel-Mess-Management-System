"""
generate_ppt.py
Generates a professional PowerPoint presentation for:
"Smart Hostel Food Waste Management System" (Java Project)
Requires: pip install python-pptx
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt
import os

# ── Color Palette ──────────────────────────────────────────────────────────────
GREEN_DARK   = RGBColor(0x1B, 0x5E, 0x20)   # Deep green
GREEN_MID    = RGBColor(0x2E, 0x7D, 0x32)   # Medium green
GREEN_LIGHT  = RGBColor(0x66, 0xBB, 0x6A)   # Accent green
WHITE        = RGBColor(0xFF, 0xFF, 0xFF)
GRAY_LIGHT   = RGBColor(0xF1, 0xF8, 0xE9)   # Very light green-white
GRAY_TEXT    = RGBColor(0x37, 0x47, 0x4F)   # Dark blue-gray for body text
ACCENT_TEAL  = RGBColor(0x00, 0x89, 0x7B)   # Teal accent
ACCENT_AMBER = RGBColor(0xF5, 0x7F, 0x17)   # Amber for highlights

prs = Presentation()
prs.slide_width  = Inches(13.33)
prs.slide_height = Inches(7.5)

BLANK = prs.slide_layouts[6]   # fully blank layout

# ── Helper: add rectangle shape ────────────────────────────────────────────────
def add_rect(slide, l, t, w, h, fill_color, alpha=None):
    shape = slide.shapes.add_shape(1, Inches(l), Inches(t), Inches(w), Inches(h))
    shape.line.fill.background()
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    return shape

# ── Helper: add text box ───────────────────────────────────────────────────────
def add_text(slide, text, l, t, w, h, font_size=18, bold=False, color=WHITE,
             align=PP_ALIGN.LEFT, italic=False, wrap=True):
    txBox = slide.shapes.add_textbox(Inches(l), Inches(t), Inches(w), Inches(h))
    tf = txBox.text_frame
    tf.word_wrap = wrap
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = "Calibri"
    return txBox

# ── Helper: add bullet slide ───────────────────────────────────────────────────
def add_bullet_slide(title_text, bullets, icon=""):
    slide = prs.slides.add_slide(BLANK)
    # Background
    add_rect(slide, 0, 0, 13.33, 7.5, GRAY_LIGHT)
    # Left accent bar
    add_rect(slide, 0, 0, 0.15, 7.5, GREEN_MID)
    # Title bar
    add_rect(slide, 0.15, 0, 13.18, 1.2, GREEN_DARK)
    # Title text
    add_text(slide, icon + " " + title_text if icon else title_text,
             0.4, 0.15, 12.5, 0.9, font_size=28, bold=True, color=WHITE)
    # Bullets
    y = 1.45
    for bullet in bullets:
        add_text(slide, bullet, 0.7, y, 12.0, 0.5,
                 font_size=17, bold=False, color=GRAY_TEXT)
        y += 0.55
    return slide

# ── Helper: add two-column slide ──────────────────────────────────────────────
def add_two_col_slide(title_text, left_title, left_items, right_title, right_items, icon=""):
    slide = prs.slides.add_slide(BLANK)
    add_rect(slide, 0, 0, 13.33, 7.5, GRAY_LIGHT)
    add_rect(slide, 0, 0, 0.15, 7.5, GREEN_MID)
    add_rect(slide, 0.15, 0, 13.18, 1.2, GREEN_DARK)
    add_text(slide, icon + " " + title_text if icon else title_text,
             0.4, 0.15, 12.5, 0.9, font_size=28, bold=True, color=WHITE)
    # Left column box
    add_rect(slide, 0.4, 1.45, 5.9, 5.6, GREEN_MID)
    add_text(slide, left_title, 0.5, 1.5, 5.6, 0.55, font_size=16, bold=True, color=WHITE)
    y = 2.1
    for item in left_items:
        add_text(slide, "  • " + item, 0.5, y, 5.7, 0.55, font_size=15, color=WHITE)
        y += 0.52
    # Right column box
    add_rect(slide, 6.9, 1.45, 6.0, 5.6, ACCENT_TEAL)
    add_text(slide, right_title, 7.0, 1.5, 5.8, 0.55, font_size=16, bold=True, color=WHITE)
    y = 2.1
    for item in right_items:
        add_text(slide, "  • " + item, 7.0, y, 5.8, 0.55, font_size=15, color=WHITE)
        y += 0.52
    return slide

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 1 — Title Slide
# ══════════════════════════════════════════════════════════════════════════════
slide1 = prs.slides.add_slide(BLANK)
# Full-page gradient feel via two layered rectangles
add_rect(slide1, 0, 0, 13.33, 7.5, GREEN_DARK)
add_rect(slide1, 0, 4.5, 13.33, 3.0, GREEN_MID)
# Decorative accent strip
add_rect(slide1, 0, 4.35, 13.33, 0.18, GREEN_LIGHT)
# Big icon / emoji label
add_text(slide1, "🌿", 0.5, 0.4, 3, 1.5, font_size=60, color=GREEN_LIGHT)
# Main title
add_text(slide1,
         "Smart Hostel Food Waste\nManagement System",
         0.5, 1.3, 12, 1.8, font_size=42, bold=True, color=WHITE, align=PP_ALIGN.LEFT)
# Subtitle
add_text(slide1,
         "A Java-Based Desktop Application for Sustainable Hostel Operations",
         0.5, 3.3, 11.5, 0.7, font_size=20, italic=True, color=GREEN_LIGHT)
# Bottom bar details
add_text(slide1, "College Project  |  Java Swing GUI  |  2026",
         0.5, 5.1, 12, 0.6, font_size=16, color=WHITE, align=PP_ALIGN.CENTER)
add_text(slide1,
         "Modules: Dashboard • Meal Booking • Waste Segregation • Composting • Donation • Reports",
         0.5, 5.8, 12.3, 0.5, font_size=13, color=GREEN_LIGHT, align=PP_ALIGN.CENTER)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 2 — Problem Statement
# ══════════════════════════════════════════════════════════════════════════════
add_bullet_slide(
    "Problem Statement", icon="⚠️",
    bullets=[
        "➤  Hostels generate large quantities of food waste daily due to over-preparation and poor tracking.",
        "➤  No structured system exists to monitor, segregate, or redirect surplus food.",
        "➤  Inedible waste is often discarded without composting, leading to environmental harm.",
        "➤  Lack of data-driven insights prevents effective meal planning and resource allocation.",
        "➤  Students and administrators have no unified platform to manage meal bookings and waste.",
        "➤  Surplus edible food could save resources if donated to NGOs — but coordination is missing.",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 3 — Objectives
# ══════════════════════════════════════════════════════════════════════════════
add_bullet_slide(
    "Project Objectives", icon="🎯",
    bullets=[
        "✅  Build a desktop Java Swing GUI application for hostel food waste management.",
        "✅  Implement role-based access: Admin sees all modules; Students see Meal Booking only.",
        "✅  Track food preparation, consumption, and waste in real-time.",
        "✅  Facilitate donation of surplus edible food to NGOs with threshold-based alerts.",
        "✅  Convert inedible waste to fertilizer via a configurable composting pipeline.",
        "✅  Generate exportable reports (PDF/TXT) for hostel administration.",
        "✅  Provide visual analytics through charts on the Dashboard.",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 4 — System Architecture
# ══════════════════════════════════════════════════════════════════════════════
add_bullet_slide(
    "System Architecture", icon="🏗️",
    bullets=[
        "📦  Package: com.hostel.foodwaste — 4 sub-packages (models, services, ui, utils)",
        "🖥️   UI Layer:      Java Swing — MainAppFrame (CardLayout) + 7 Panels",
        "⚙️   Service Layer: 9 service classes handling business logic",
        "📋   Model Layer:   8 domain models (Food, Student, Admin, MealBooking, CompostBatch…)",
        "🛠️   Utils Layer:   WasteFileHandler (I/O), DBConnection, WasteOperations (interface)",
        "🔁   Flow:  Login → Role Check → Sidebar Navigation → Module Panel → Report Export",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 5 — Module Overview (Two Columns)
# ══════════════════════════════════════════════════════════════════════════════
add_two_col_slide(
    "Application Modules", icon="📦",
    left_title="Admin Modules",
    left_items=[
        "📊 Dashboard — KPI cards + charts",
        "♻️  Waste Segregation — log & categorize",
        "🌱 Composting — inedible → fertilizer",
        "🤝 Donation — surplus → NGO alerts",
        "📋 Reports — export TXT/PDF",
    ],
    right_title="Student Modules",
    right_items=[
        "🍝 Meal Booking — book / cancel meals",
        "🥗 Special Meal Request — custom orders",
        "🔐 Login — role-based authentication",
        "",
        "Both roles share the Login Panel",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 6 — Key Classes & OOP Concepts
# ══════════════════════════════════════════════════════════════════════════════
add_two_col_slide(
    "OOP Concepts Applied", icon="☕",
    left_title="OOP Pillars Used",
    left_items=[
        "Encapsulation — private fields + getters",
        "Inheritance — User → Student / Admin",
        "Polymorphism — overloaded donate()",
        "Abstraction — WasteOperations interface",
        "Inner Class — WasteManager.WasteRecord",
    ],
    right_title="Key Classes",
    right_items=[
        "WasteManager  (implements WasteOperations)",
        "DonationService  (threshold alerts)",
        "CompostingService  (0.3 conversion ratio)",
        "MealBookingService  (booking logic)",
        "FoodRepository  (food item store)",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 7 — Waste Segregation & Composting
# ══════════════════════════════════════════════════════════════════════════════
add_bullet_slide(
    "Waste Segregation & Composting", icon="♻️",
    bullets=[
        "🗂️   WasteSegregationPanel allows logging waste by food name, quantity, and reason.",
        "📝   WasteManager stores records in ArrayList<WasteRecord> with auto-incrementing IDs.",
        "🔍   Records searchable by food name; total waste calculated dynamically.",
        "🌱   CompostingService converts inedible waste at default ratio of 30% → fertilizer units.",
        "📦   Each batch stored as CompostBatch model with input/output details and date.",
        "📊   Batch history accessible for reporting and trend analysis.",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 8 — Donation & Meal Booking
# ══════════════════════════════════════════════════════════════════════════════
add_two_col_slide(
    "Donation & Meal Booking", icon="🤝",
    left_title="Donation Module",
    left_items=[
        "Threshold: 5.0 kg edible surplus",
        "Alert generated above threshold",
        "Logs: food name, qty, NGO, date",
        "Overloaded donate() for flexibility",
        "Total donated kg tracked",
    ],
    right_title="Meal Booking Module",
    right_items=[
        "Students book/cancel meals",
        "MealBookingService manages slots",
        "StudentAttendance tracking",
        "SpecialMealService for requests",
        "Meal data feeds waste analytics",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 9 — Reports & Dashboard
# ══════════════════════════════════════════════════════════════════════════════
add_bullet_slide(
    "Dashboard & Reports", icon="📊",
    bullets=[
        "📈  DashboardPanel shows KPI cards: Prepared, Consumed, Wasted, Donated, Meals Booked.",
        "📉  ChartFactory generates visual bar/pie charts for waste trend analysis.",
        "🖨️   ReportsPanel exports data to TXT (report_export.txt) for record-keeping.",
        "🗓️   Reports include: date, waste summary, donation log, and activity log.",
        "🔄  Data flows from WasteFileHandler (file I/O) and DataRepository (in-memory store).",
        "📌  Admin can view consolidated weekly/monthly waste statistics.",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 10 — Technologies & Tools
# ══════════════════════════════════════════════════════════════════════════════
add_two_col_slide(
    "Technologies & Tools", icon="🛠️",
    left_title="Core Technologies",
    left_items=[
        "Java SE (core language)",
        "Java Swing (GUI framework)",
        "CardLayout (panel navigation)",
        "BoxLayout / BorderLayout",
        "File I/O (WasteFileHandler)",
    ],
    right_title="Development Tools",
    right_items=[
        "IntelliJ IDEA / VS Code",
        "JDK 11+",
        "Custom UIConstants (theme)",
        "javac (command-line compile)",
        "sources.txt (batch build list)",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 11 — Future Enhancements
# ══════════════════════════════════════════════════════════════════════════════
add_bullet_slide(
    "Future Enhancements", icon="🚀",
    bullets=[
        "☁️   Cloud / Database integration (MySQL / Firebase) for persistent storage.",
        "📱  Android / Web version for mobile-first hostel management.",
        "🤖  AI-based meal demand prediction to minimize over-preparation.",
        "📲  Push notifications for donation threshold alerts via email/SMS.",
        "🗺️   GPS-based NGO finder to optimize food donation routing.",
        "📈  Advanced analytics — monthly trends, wastage heatmaps, cost savings reports.",
        "🔒  Enhanced security — password hashing, session management.",
    ]
)

# ══════════════════════════════════════════════════════════════════════════════
#  SLIDE 12 — Conclusion
# ══════════════════════════════════════════════════════════════════════════════
slide12 = prs.slides.add_slide(BLANK)
add_rect(slide12, 0, 0, 13.33, 7.5, GREEN_DARK)
add_rect(slide12, 0, 5.5, 13.33, 2.0, GREEN_MID)
add_rect(slide12, 0, 5.35, 13.33, 0.18, GREEN_LIGHT)

add_text(slide12, "🌿 Conclusion", 0.5, 0.5, 12, 0.9, font_size=34, bold=True, color=GREEN_LIGHT)
conclusions = [
    "✅  Successfully built a full-stack Java Swing desktop application.",
    "✅  Covers the complete food-waste lifecycle: booking → tracking → donation → composting.",
    "✅  Role-based access ensures appropriate data visibility for students and admins.",
    "✅  Demonstrates real-world OOP concepts: inheritance, polymorphism, interfaces.",
    "✅  Exportable reports support data-driven hostel management decisions.",
]
y = 1.55
for c in conclusions:
    add_text(slide12, c, 0.7, y, 12, 0.55, font_size=17, color=WHITE)
    y += 0.58

add_text(slide12, "Thank You!", 0, 5.6, 13.33, 0.8,
         font_size=30, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
add_text(slide12, "Smart Hostel Food Waste Management System  |  College Project  |  2026",
         0, 6.5, 13.33, 0.5, font_size=14, italic=True, color=GREEN_LIGHT, align=PP_ALIGN.CENTER)

# ── Save ───────────────────────────────────────────────────────────────────────
output_path = os.path.join(os.path.dirname(__file__),
                           "Smart_Hostel_FoodWaste_PPT.pptx")
prs.save(output_path)
print(f"\nPresentation saved successfully to:\n    {output_path}")
print(f"    Total slides: {len(prs.slides)}")
