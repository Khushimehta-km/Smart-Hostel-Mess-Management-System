package com.hostel.foodwaste.models;

/**
 * Class: Student (extends User)
 * Represents a hostel student who is tracked for food waste.
 */
public class Student extends User {

    private String roomNumber;
    private String mealPlan;
    private int    wastePointsDeducted;

    public Student() {
        super();
        this.roomNumber          = "N/A";
        this.mealPlan            = "Standard";
        this.wastePointsDeducted = 0;
        this.role                = "STUDENT";
    }

    public Student(int userId, String username, String password,
                   String roomNumber, String mealPlan) {
        super(userId, username, password, "STUDENT");
        this.roomNumber          = roomNumber;
        this.mealPlan            = mealPlan;
        this.wastePointsDeducted = 0;
    }

    @Override
    public String getDashboardGreeting() {
        return "Hello, Student " + getUsername() + "!" +
               " | Room: " + roomNumber +
               " | Meal Plan: " + mealPlan +
               " | Waste Points Lost: " + wastePointsDeducted;
    }

    public void deductPoints(int points) {
        this.wastePointsDeducted += points;
        System.out.println(points + " waste points deducted from " + getUsername());
    }

    public void deductPoints(int points, String reason) {
        this.wastePointsDeducted += points;
        System.out.println(points + " points deducted from " + getUsername() +
                           " | Reason: " + reason);
    }

    public String getRoomNumber()          { return roomNumber; }
    public String getMealPlan()            { return mealPlan; }
    public int    getWastePointsDeducted() { return wastePointsDeducted; }

    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public void setMealPlan(String mealPlan)     { this.mealPlan   = mealPlan; }

    @Override
    public String toString() {
        return super.toString() +
               " | Room: " + roomNumber +
               " | Plan: " + mealPlan +
               " | Waste Points Lost: " + wastePointsDeducted;
    }
}
