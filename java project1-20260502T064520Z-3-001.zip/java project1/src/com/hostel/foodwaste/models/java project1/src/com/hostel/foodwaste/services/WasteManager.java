package com.hostel.foodwaste.services;

import com.hostel.foodwaste.services.DataRepository;
import com.hostel.foodwaste.models.Food;
import com.hostel.foodwaste.utils.WasteOperations;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Class: WasteManager
 * Implements WasteOperations interface.
 * Uses an inner WasteRecord class stored in ArrayList<WasteRecord>.
 */
public class WasteManager implements WasteOperations {

    // ── Inner Class: WasteRecord ──────────────────────────────────────────
    public static class WasteRecord {
        private int recordId;
        private String foodName;
        private double quantityKg;
        private String reason;
        private String date;

        public WasteRecord(int recordId, String foodName,
                double quantityKg, String reason, String date) {
            this.recordId = recordId;
            this.foodName = foodName;
            this.quantityKg = quantityKg;
            this.reason = reason;
            this.date = date;
        }

        public int getRecordId() {
            return recordId;
        }

        public String getFoodName() {
            return foodName;
        }

        public double getQuantityKg() {
            return quantityKg;
        }

        public String getReason() {
            return reason;
        }

        public String getDate() {
            return date;
        }

        @Override
        public String toString() {
            return "Record#" + recordId +
                    " | Food: " + foodName +
                    " | Qty: " + quantityKg + " kg" +
                    " | Reason: " + reason +
                    " | Date: " + date;
        }
    }

    private String managerName;
    private List<WasteRecord> wasteLog;
    private int nextRecordId;

    public WasteManager() {
        this("System");
    }

    public WasteManager(String managerName) {
        this.managerName = managerName;
        this.wasteLog = new ArrayList<>();
        this.nextRecordId = 1;
    }

    @Override
    public void logWaste(Food food, double quantityKg, String reason) {
        logWaste(food, quantityKg, reason, LocalDate.now().toString());
    }

    @Override
    public void logWaste(Food food, double quantityKg, String reason, String date) {
        WasteRecord record = new WasteRecord(nextRecordId, food.getName(),
                quantityKg, reason, date);
        wasteLog.add(record);
        nextRecordId++;
    }

    @Override
    public void removeWasteRecord(int recordId) {
        wasteLog.removeIf(r -> r.getRecordId() == recordId);
    }

    @Override
    public List<String> getWasteSummary() {
        List<String> summary = new ArrayList<>();
        for (WasteRecord r : wasteLog) {
            summary.add(r.toString());
        }
        return summary;
    }

    public void logWaste(String foodName, double quantityKg) {
        Food temp = new Food(foodName, "Unknown", quantityKg, "N/A");
        logWaste(temp, quantityKg, "Quick log");
    }

    public void saveWasteToDB(String meal, int waste) {
        DataRepository repo = new DataRepository();
        repo.saveWasteData(meal, waste);
    }

    public List<WasteRecord> findByFoodName(String foodName) {
        List<WasteRecord> result = new ArrayList<>();
        for (WasteRecord r : wasteLog) {
            if (r.getFoodName().equalsIgnoreCase(foodName)) {
                result.add(r);
            }
        }
        return result;
    }

    public double getTotalWasteKg() {
        double total = 0;
        for (WasteRecord r : wasteLog) {
            total += r.getQuantityKg();
        }
        return total;
    }

    public String getManagerName() {
        return managerName;
    }

    public int getTotalRecords() {
        return wasteLog.size();
    }

    public List<WasteRecord> getWasteLog() {
        return new ArrayList<>(wasteLog);
    }
}
