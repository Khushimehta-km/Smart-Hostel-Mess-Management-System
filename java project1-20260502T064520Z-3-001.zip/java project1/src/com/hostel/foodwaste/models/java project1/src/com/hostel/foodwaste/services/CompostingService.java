package com.hostel.foodwaste.services;

import com.hostel.foodwaste.models.CompostBatch;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Class: CompostingService
 * Simulates the composting process — converting inedible waste into fertilizer units.
 *
 * Features:
 *   - Process inedible waste into fertilizer
 *   - Configurable conversion ratio (default 0.3)
 *   - Batch history stored in ArrayList<CompostBatch>
 */
public class CompostingService {

    // ── Constants ─────────────────────────────────────────────────────────
    private static final double DEFAULT_CONVERSION_RATIO = 0.3;

    // ── Fields ────────────────────────────────────────────────────────────
    private List<CompostBatch> batchHistory;
    private double conversionRatio;
    private int nextBatchId;

    // ── Constructors ──────────────────────────────────────────────────────
    public CompostingService() {
        this(DEFAULT_CONVERSION_RATIO);
    }

    public CompostingService(double conversionRatio) {
        this.conversionRatio = conversionRatio;
        this.batchHistory    = new ArrayList<>();
        this.nextBatchId     = 1;
    }

    // ── Process waste into fertilizer ─────────────────────────────────────
    public CompostBatch processWaste(double inedibleWasteKg) {
        return processWaste(inedibleWasteKg, LocalDate.now().toString());
    }

    public CompostBatch processWaste(double inedibleWasteKg, String date) {
        if (inedibleWasteKg <= 0) {
            System.out.println("[CompostingService] Invalid waste quantity.");
            return null;
        }
        CompostBatch batch = new CompostBatch(nextBatchId++, inedibleWasteKg, conversionRatio, date);
        batchHistory.add(batch);
        return batch;
    }

    // ── Get total fertilizer produced ─────────────────────────────────────
    public double getTotalFertilizerProduced() {
        double total = 0;
        for (CompostBatch b : batchHistory) {
            total += b.getOutputFertilizerUnits();
        }
        return total;
    }

    // ── Get total waste processed ─────────────────────────────────────────
    public double getTotalWasteProcessed() {
        double total = 0;
        for (CompostBatch b : batchHistory) {
            total += b.getInputWasteKg();
        }
        return total;
    }

    // ── Get batch history ─────────────────────────────────────────────────
    public List<CompostBatch> getBatchHistory() {
        return new ArrayList<>(batchHistory);
    }

    // ── Getters & Setters ─────────────────────────────────────────────────
    public double getConversionRatio()             { return conversionRatio; }
    public int    getTotalBatches()                { return batchHistory.size(); }
    public void   setConversionRatio(double ratio) { this.conversionRatio = ratio; }
}
