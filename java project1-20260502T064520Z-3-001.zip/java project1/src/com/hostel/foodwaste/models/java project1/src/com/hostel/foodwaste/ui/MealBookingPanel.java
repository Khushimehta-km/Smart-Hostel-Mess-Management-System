package com.hostel.foodwaste.ui;

import com.hostel.foodwaste.services.MealBookingService;
import com.hostel.foodwaste.models.MealBooking;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.Map;

/**
 * MealBookingPanel — Meal Booking System with summary cards
 * and suggested preparation quantities.
 */
public class MealBookingPanel extends JPanel {

    private final MealBookingService bookingService = new MealBookingService();
    private JTextField tfStudentId, tfStudentName, tfRoomNumber, tfDate;
    private JCheckBox chkBreakfast, chkLunch, chkSnacks, chkDinner;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblStatus;
    // Stat labels
    private JLabel lblBreakfast, lblLunch, lblSnacks, lblDinner, lblTotal, lblSuggested;

    public MealBookingPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UIConstants.BG_MAIN);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        add(buildTopSection(), BorderLayout.NORTH);
        add(buildCenterSection(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
    }

    private JPanel buildTopSection() {
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setOpaque(false);

        // Summary Cards
        JPanel stats = new JPanel(new GridLayout(1, 6, 8, 0));
        stats.setOpaque(false);

        JPanel cb = UIConstants.createStatCard("0", "Breakfast", UIConstants.ACCENT_ORANGE);
        lblBreakfast = (JLabel)((BorderLayout)cb.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        stats.add(cb);
        JPanel cl = UIConstants.createStatCard("0", "Lunch", UIConstants.ACCENT_GREEN);
        lblLunch = (JLabel)((BorderLayout)cl.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        stats.add(cl);
        JPanel cs = UIConstants.createStatCard("0", "Snacks", UIConstants.ACCENT_PURPLE);
        lblSnacks = (JLabel)((BorderLayout)cs.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        stats.add(cs);
        JPanel cd = UIConstants.createStatCard("0", "Dinner", UIConstants.ACCENT_BLUE);
        lblDinner = (JLabel)((BorderLayout)cd.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        stats.add(cd);
        JPanel ct = UIConstants.createStatCard("0", "Total Confirmed", UIConstants.PRIMARY);
        lblTotal = (JLabel)((BorderLayout)ct.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        stats.add(ct);
        JPanel cq = UIConstants.createStatCard("0.0 kg", "Suggested Qty", UIConstants.ACCENT_RED);
        lblSuggested = (JLabel)((BorderLayout)cq.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        stats.add(cq);

        top.add(stats, BorderLayout.NORTH);

        // Booking Form
        JPanel form = UIConstants.createCard();
        form.setLayout(new GridBagLayout());
        form.setBorder(UIConstants.createThemedTitledBorder("Meal Booking Form", UIConstants.PRIMARY));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx=0;g.gridy=0;form.add(label("Student ID:"),g);
        g.gridx=1;g.weightx=1;tfStudentId=field(12);form.add(tfStudentId,g);
        g.gridx=2;g.weightx=0;form.add(label("Student Name:"),g);
        g.gridx=3;g.weightx=1;tfStudentName=field(12);form.add(tfStudentName,g);

        g.gridx=0;g.gridy=1;g.weightx=0;form.add(label("Room No:"),g);
        g.gridx=1;g.weightx=1;tfRoomNumber=field(12);form.add(tfRoomNumber,g);
        g.gridx=2;g.weightx=0;form.add(label("Meal Type:"),g);
        g.gridx=3;g.weightx=1;
        JPanel mealPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        mealPanel.setOpaque(false);
        chkBreakfast = new JCheckBox("Breakfast");
        chkLunch     = new JCheckBox("Lunch");
        chkSnacks    = new JCheckBox("Snacks");
        chkDinner    = new JCheckBox("Dinner");
        
        // Styling checkboxes
        Font chkFont = UIConstants.FONT_BODY;
        chkBreakfast.setFont(chkFont); chkBreakfast.setOpaque(false);
        chkLunch.setFont(chkFont);     chkLunch.setOpaque(false);
        chkSnacks.setFont(chkFont);    chkSnacks.setOpaque(false);
        chkDinner.setFont(chkFont);    chkDinner.setOpaque(false);
        
        mealPanel.add(chkBreakfast); mealPanel.add(chkLunch);
        mealPanel.add(chkSnacks);    mealPanel.add(chkDinner);
        form.add(mealPanel, g);

        g.gridx=0;g.gridy=2;g.weightx=0;form.add(label("Date:"),g);
        g.gridx=1;g.weightx=1;tfDate=new JTextField(LocalDate.now().toString(),12);
        tfDate.setFont(UIConstants.FONT_BODY);form.add(tfDate,g);

        g.gridx=2;g.weightx=0;
        JButton btnBook=UIConstants.createStyledButton("Book Meal",UIConstants.BTN_SUCCESS);
        btnBook.addActionListener(e->handleBook());form.add(btnBook,g);

        g.gridx=3;
        JPanel bp=new JPanel(new FlowLayout(FlowLayout.LEFT,5,0));bp.setOpaque(false);
        JButton btnClear=UIConstants.createStyledButton("Clear",UIConstants.BTN_WARNING);
        btnClear.addActionListener(e->handleClear());bp.add(btnClear);
        JButton btnRemove=UIConstants.createStyledButton("Remove",UIConstants.BTN_DANGER);
        btnRemove.addActionListener(e->handleRemove());bp.add(btnRemove);
        form.add(bp,g);

        top.add(form, BorderLayout.CENTER);
        return top;
    }

    private JPanel buildCenterSection() {
        JPanel tc = UIConstants.createCard();
        tc.setLayout(new BorderLayout());
        JLabel tl = new JLabel("  Booking Records");
        tl.setFont(UIConstants.FONT_HEADING);
        tl.setForeground(UIConstants.PRIMARY);
        tc.add(tl, BorderLayout.NORTH);

        String[] cols = {"#","Student ID","Student Name","Room No","Meal Type","Date"};
        tableModel = new DefaultTableModel(cols, 0){
            public boolean isCellEditable(int r,int c){return false;}
        };
        table = new JTable(tableModel);
        UIConstants.styleTable(table);
        tc.add(new JScrollPane(table), BorderLayout.CENTER);
        return tc;
    }

    private JLabel buildStatusBar() {
        lblStatus = new JLabel("  Ready. Fill in the form and click 'Book Meal'.");
        lblStatus.setFont(UIConstants.FONT_SMALL_ITALIC);
        lblStatus.setForeground(UIConstants.TEXT_SECONDARY);
        return lblStatus;
    }

    private void handleBook() {
        String sid=tfStudentId.getText().trim(), sname=tfStudentName.getText().trim(),
               room=tfRoomNumber.getText().trim(),
               date=tfDate.getText().trim();

        // Collect selected meals
        java.util.List<String> selectedMeals = new java.util.ArrayList<>();
        if (chkBreakfast.isSelected()) selectedMeals.add("Breakfast");
        if (chkLunch.isSelected())     selectedMeals.add("Lunch");
        if (chkSnacks.isSelected())    selectedMeals.add("Snacks");
        if (chkDinner.isSelected())    selectedMeals.add("Dinner");

        if(sid.isEmpty()||sname.isEmpty()||room.isEmpty()){
            setStatus("Please fill in all fields.",UIConstants.ACCENT_RED);return;}
        if(selectedMeals.isEmpty()){
            setStatus("Please select at least one meal.",UIConstants.ACCENT_RED);return;}
        if(!date.matches("\\d{4}-\\d{2}-\\d{2}")){
            setStatus("Date must be YYYY-MM-DD.",UIConstants.ACCENT_RED);return;}

        String meal = String.join(", ", selectedMeals);
        MealBooking b = bookingService.addBooking(sid,sname,room,meal,date);
        tableModel.addRow(new Object[]{b.getBookingId(),sid,sname,room,meal,date});
        updateStats();
        setStatus("Meal(s) booked: "+meal,UIConstants.ACCENT_GREEN);
        handleClear();
    }

    private void handleClear() {
        tfStudentId.setText("");tfStudentName.setText("");tfRoomNumber.setText("");
        chkBreakfast.setSelected(false);
        chkLunch.setSelected(false);
        chkSnacks.setSelected(false);
        chkDinner.setSelected(false);
        tfDate.setText(LocalDate.now().toString());
    }

    private void handleRemove() {
        int row=table.getSelectedRow();
        if(row==-1){setStatus("Select a row to remove.",UIConstants.ACCENT_ORANGE);return;}
        int id=(int)tableModel.getValueAt(row,0);
        bookingService.removeBooking(id);
        tableModel.removeRow(row);
        updateStats();
        setStatus("Booking removed.",UIConstants.TEXT_SECONDARY);
    }

    private void updateStats() {
        Map<String,Integer> m = bookingService.getMealWiseSummary();
        lblBreakfast.setText(String.valueOf(m.getOrDefault("Breakfast",0)));
        lblLunch.setText(String.valueOf(m.getOrDefault("Lunch",0)));
        lblSnacks.setText(String.valueOf(m.getOrDefault("Snacks",0)));
        lblDinner.setText(String.valueOf(m.getOrDefault("Dinner",0)));
        lblTotal.setText(String.valueOf(bookingService.getTotalConfirmed()));
        lblSuggested.setText(String.format("%.1f kg",bookingService.getTotalSuggestedQuantity()));
    }

    private void setStatus(String msg,Color c){lblStatus.setText("  "+msg);lblStatus.setForeground(c);}
    private JLabel label(String t){JLabel l=new JLabel(t);l.setFont(UIConstants.FONT_BODY);return l;}
    private JTextField field(int cols){JTextField f=new JTextField(cols);f.setFont(UIConstants.FONT_BODY);return f;}
}
