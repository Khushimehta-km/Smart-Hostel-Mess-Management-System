package com.hostel.foodwaste.ui;

import com.hostel.foodwaste.services.DonationService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

/**
 * DonationPanel — Food Donation Module.
 * Shows edible waste, threshold alerts, NGO details, and donation logging.
 */
public class DonationPanel extends JPanel {

    private final DonationService donationService = new DonationService("Hostel Kitchen");
    private JTextField tfEdibleWaste, tfFoodName;
    private JComboBox<String> cbNgo;
    private JLabel lblAlert, lblStatus;
    private JPanel alertPanel;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel statTotal, statCount, statThreshold;

    public DonationPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UIConstants.BG_MAIN);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        add(buildTopSection(), BorderLayout.NORTH);
        add(buildCenterSection(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
    }

    private JPanel buildTopSection() {
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setOpaque(false);

        // Stat cards
        JPanel stats = new JPanel(new GridLayout(1, 3, 10, 0));
        stats.setOpaque(false);
        JPanel c1 = UIConstants.createStatCard("0.00 kg", "Total Donated",
                UIConstants.ACCENT_GREEN);
        statTotal = (JLabel) ((BorderLayout) c1.getLayout())
                .getLayoutComponent(BorderLayout.CENTER);
        stats.add(c1);
        JPanel c2 = UIConstants.createStatCard("0", "Donations Made",
                UIConstants.ACCENT_BLUE);
        statCount = (JLabel) ((BorderLayout) c2.getLayout())
                .getLayoutComponent(BorderLayout.CENTER);
        stats.add(c2);
        JPanel c3 = UIConstants.createStatCard(
                DonationService.DONATION_THRESHOLD + " kg", "Donation Threshold",
                UIConstants.ACCENT_ORANGE);
        statThreshold = (JLabel) ((BorderLayout) c3.getLayout())
                .getLayoutComponent(BorderLayout.CENTER);
        stats.add(c3);
        top.add(stats, BorderLayout.NORTH);

        // Alert + Form panel
        JPanel mid = new JPanel(new BorderLayout(10, 10));
        mid.setOpaque(false);

        // Alert panel
        alertPanel = new JPanel(new BorderLayout());
        alertPanel.setBackground(new Color(255, 243, 224));
        alertPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UIConstants.ACCENT_ORANGE, 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)));
        lblAlert = new JLabel("Enter edible waste quantity to check donation eligibility.");
        lblAlert.setFont(UIConstants.FONT_BODY);
        lblAlert.setForeground(UIConstants.ACCENT_ORANGE);
        alertPanel.add(lblAlert, BorderLayout.CENTER);
        mid.add(alertPanel, BorderLayout.NORTH);

        // Input form
        JPanel form = UIConstants.createCard();
        form.setLayout(new GridBagLayout());
        form.setBorder(UIConstants.createThemedTitledBorder(
                "Food Donation Form", UIConstants.ACCENT_PINK));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx = 0; g.gridy = 0;
        form.add(label("Food Name:"), g);
        g.gridx = 1; g.weightx = 1;
        tfFoodName = new JTextField(12);
        tfFoodName.setFont(UIConstants.FONT_BODY);
        form.add(tfFoodName, g);

        g.gridx = 2; g.weightx = 0;
        form.add(label("Edible Waste (kg):"), g);
        g.gridx = 3; g.weightx = 1;
        tfEdibleWaste = new JTextField(10);
        tfEdibleWaste.setFont(UIConstants.FONT_BODY);
        form.add(tfEdibleWaste, g);

        g.gridx = 0; g.gridy = 1; g.weightx = 0;
        form.add(label("Select NGO:"), g);
        g.gridx = 1; g.weightx = 1;
        cbNgo = new JComboBox<>(new String[]{
            "City Food Bank (9876543210)",
            "Helping Hands Foundation (9123456789)",
            "Annapurna Trust (8765432100)"
        });
        cbNgo.setFont(UIConstants.FONT_BODY);
        form.add(cbNgo, g);

        g.gridx = 2; g.weightx = 0;
        JButton btnCheck = UIConstants.createStyledButton("Check Eligibility",
                UIConstants.BTN_INFO);
        btnCheck.addActionListener(e -> handleCheck());
        form.add(btnCheck, g);

        g.gridx = 3;
        JButton btnDonate = UIConstants.createStyledButton("Mark as Donated",
                UIConstants.BTN_SUCCESS);
        btnDonate.addActionListener(e -> handleDonate());
        form.add(btnDonate, g);

        // NGO details
        g.gridx = 0; g.gridy = 2; g.gridwidth = 4;
        JPanel ngoPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        ngoPanel.setOpaque(false);
        ngoPanel.add(ngoCard("City Food Bank", "9876543210", "Delhi"));
        ngoPanel.add(ngoCard("Helping Hands", "9123456789", "Mumbai"));
        ngoPanel.add(ngoCard("Annapurna Trust", "8765432100", "Bangalore"));
        form.add(ngoPanel, g);

        mid.add(form, BorderLayout.CENTER);
        top.add(mid, BorderLayout.CENTER);
        return top;
    }

    private JPanel buildCenterSection() {
        JPanel tc = UIConstants.createCard();
        tc.setLayout(new BorderLayout());
        JLabel tl = new JLabel("  Donation History");
        tl.setFont(UIConstants.FONT_HEADING);
        tl.setForeground(UIConstants.ACCENT_PINK);
        tc.add(tl, BorderLayout.NORTH);

        String[] cols = {"#", "Food Name", "Qty (kg)", "NGO", "Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UIConstants.styleTable(table);
        table.getTableHeader().setBackground(UIConstants.ACCENT_PINK);
        tc.add(new JScrollPane(table), BorderLayout.CENTER);
        return tc;
    }

    private JLabel buildStatusBar() {
        lblStatus = new JLabel("  Ready. Enter food details for donation.");
        lblStatus.setFont(UIConstants.FONT_SMALL_ITALIC);
        lblStatus.setForeground(UIConstants.TEXT_SECONDARY);
        return lblStatus;
    }

    private void handleCheck() {
        try {
            double qty = Double.parseDouble(tfEdibleWaste.getText().trim());
            String alert = donationService.getDonationAlert(qty);
            boolean eligible = donationService.isEligibleForDonation(qty);
            lblAlert.setText(alert);
            if (eligible) {
                alertPanel.setBackground(new Color(232, 245, 233));
                alertPanel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UIConstants.ACCENT_GREEN, 2),
                    BorderFactory.createEmptyBorder(10, 15, 10, 15)));
                lblAlert.setForeground(UIConstants.ACCENT_GREEN);
                lblAlert.setText("\uD83D\uDD14 " + alert);
            } else {
                alertPanel.setBackground(new Color(255, 243, 224));
                alertPanel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UIConstants.ACCENT_ORANGE, 1),
                    BorderFactory.createEmptyBorder(10, 15, 10, 15)));
                lblAlert.setForeground(UIConstants.ACCENT_ORANGE);
            }
        } catch (NumberFormatException ex) {
            setStatus("Enter a valid quantity.", UIConstants.ACCENT_RED);
        }
    }

    private void handleDonate() {
        String food = tfFoodName.getText().trim();
        String qtyText = tfEdibleWaste.getText().trim();
        if (food.isEmpty() || qtyText.isEmpty()) {
            setStatus("Fill in food name and quantity.", UIConstants.ACCENT_RED);
            return;
        }
        try {
            double qty = Double.parseDouble(qtyText);
            if (qty <= 0) {
                setStatus("Quantity must be positive.", UIConstants.ACCENT_RED);
                return;
            }
            String ngo = ((String) cbNgo.getSelectedItem()).split("\\(")[0].trim();
            String date = LocalDate.now().toString();
            donationService.donate(food, qty, ngo, date);

            tableModel.addRow(new Object[]{
                tableModel.getRowCount() + 1, food,
                String.format("%.2f", qty), ngo, date
            });
            statTotal.setText(String.format("%.2f kg",
                    donationService.getTotalDonatedKg()));
            statCount.setText(String.valueOf(donationService.getTotalDonations()));
            setStatus("Donated " + qty + " kg of " + food + " to " + ngo,
                    UIConstants.ACCENT_GREEN);
            tfFoodName.setText("");
            tfEdibleWaste.setText("");
        } catch (NumberFormatException ex) {
            setStatus("Enter a valid number.", UIConstants.ACCENT_RED);
        }
    }

    private JPanel ngoCard(String name, String phone, String city) {
        JPanel p = new JPanel(new BorderLayout(2, 2));
        p.setBackground(new Color(248, 245, 252));
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 215, 230), 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        JLabel n = new JLabel(name, JLabel.CENTER);
        n.setFont(UIConstants.FONT_BODY_BOLD);
        n.setForeground(UIConstants.ACCENT_PURPLE);
        p.add(n, BorderLayout.NORTH);
        JLabel d = new JLabel(phone + " | " + city, JLabel.CENTER);
        d.setFont(UIConstants.FONT_SMALL);
        d.setForeground(UIConstants.TEXT_SECONDARY);
        p.add(d, BorderLayout.CENTER);
        return p;
    }

    private void setStatus(String msg, Color c) {
        lblStatus.setText("  " + msg);
        lblStatus.setForeground(c);
    }

    private JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setFont(UIConstants.FONT_BODY);
        return l;
    }
}
