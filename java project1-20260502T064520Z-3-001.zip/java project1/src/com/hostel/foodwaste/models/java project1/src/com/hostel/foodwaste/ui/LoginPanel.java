package com.hostel.foodwaste.ui;

import com.hostel.foodwaste.models.Admin;
import com.hostel.foodwaste.models.Student;
import com.hostel.foodwaste.models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

/**
 * Class: LoginPanel
 * Provides a login screen with Admin/Student simulation.
 * Hardcoded credentials:
 *   Admin:   warden / admin@99
 *   Student: arjun  / pass123
 */
public class LoginPanel extends JPanel {

    private JTextField     tfUsername;
    private JPasswordField tfPassword;
    private JLabel         lblStatus;
    private MainAppFrame   parentFrame;

    // ── Hardcoded users ───────────────────────────────────────────────────
    private final Admin   adminUser   = new Admin(1, "warden", "admin@99", "Block A");
    private final Student studentUser = new Student(101, "arjun", "pass123", "A-204", "Full Board");

    public LoginPanel(MainAppFrame parentFrame) {
        this.parentFrame = parentFrame;
        setLayout(new GridBagLayout());
        setBackground(UIConstants.BG_MAIN);
        buildUI();
    }

    private void buildUI() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        // ── Login Card ────────────────────────────────────────────────────
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(UIConstants.BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 210, 220), 1),
            BorderFactory.createEmptyBorder(30, 40, 30, 40)
        ));
        card.setPreferredSize(new Dimension(420, 380));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 5, 8, 5);
        c.fill   = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 2;

        // ── Icon ──────────────────────────────────────────────────────────
        c.gridx = 0; c.gridy = 0;
        JLabel icon = new JLabel("\uD83C\uDF3F", JLabel.CENTER);  // 🌿
        icon.setFont(new Font("SansSerif", Font.PLAIN, 48));
        card.add(icon, c);

        // ── Title ─────────────────────────────────────────────────────────
        c.gridy = 1;
        JLabel title = new JLabel("Hostel Food Waste Manager", JLabel.CENTER);
        title.setFont(UIConstants.FONT_TITLE);
        title.setForeground(UIConstants.PRIMARY_DARK);
        card.add(title, c);

        // ── Subtitle ──────────────────────────────────────────────────────
        c.gridy = 2;
        JLabel subtitle = new JLabel("Sign in to continue", JLabel.CENTER);
        subtitle.setFont(UIConstants.FONT_SMALL);
        subtitle.setForeground(UIConstants.TEXT_SECONDARY);
        card.add(subtitle, c);

        // ── Spacer ────────────────────────────────────────────────────────
        c.gridy = 3;
        card.add(Box.createVerticalStrut(10), c);

        // ── Username ──────────────────────────────────────────────────────
        c.gridy = 4; c.gridwidth = 1;
        c.gridx = 0; c.weightx = 0;
        JLabel lblUser = new JLabel("Username:");
        lblUser.setFont(UIConstants.FONT_BODY);
        card.add(lblUser, c);

        c.gridx = 1; c.weightx = 1;
        tfUsername = new JTextField(18);
        tfUsername.setFont(UIConstants.FONT_BODY);
        tfUsername.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 210, 220)),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        card.add(tfUsername, c);

        // ── Password ──────────────────────────────────────────────────────
        c.gridy = 5; c.gridx = 0; c.weightx = 0;
        JLabel lblPass = new JLabel("Password:");
        lblPass.setFont(UIConstants.FONT_BODY);
        card.add(lblPass, c);

        c.gridx = 1; c.weightx = 1;
        tfPassword = new JPasswordField(18);
        tfPassword.setFont(UIConstants.FONT_BODY);
        tfPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 210, 220)),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        card.add(tfPassword, c);

        // ── Login Button ──────────────────────────────────────────────────
        c.gridy = 6; c.gridx = 0; c.gridwidth = 2;
        c.insets = new Insets(15, 5, 5, 5);
        JButton btnLogin = UIConstants.createStyledButton("  Sign In  ", UIConstants.PRIMARY);
        btnLogin.setFont(UIConstants.FONT_SUBTITLE);
        btnLogin.addActionListener(e -> handleLogin());
        card.add(btnLogin, c);

        // ── Skip Button ───────────────────────────────────────────────────
        c.gridy = 7;
        c.insets = new Insets(5, 5, 5, 5);
        JButton btnSkip = new JButton("Continue as Guest");
        btnSkip.setFont(UIConstants.FONT_SMALL);
        btnSkip.setForeground(UIConstants.PRIMARY_LIGHT);
        btnSkip.setBackground(UIConstants.BG_CARD);
        btnSkip.setBorderPainted(false);
        btnSkip.setFocusPainted(false);
        btnSkip.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnSkip.addActionListener(e -> parentFrame.onLoginSuccess(null, "Guest"));
        card.add(btnSkip, c);

        // ── Status Label ──────────────────────────────────────────────────
        c.gridy = 8;
        lblStatus = new JLabel(" ", JLabel.CENTER);
        lblStatus.setFont(UIConstants.FONT_SMALL);
        lblStatus.setForeground(UIConstants.ACCENT_RED);
        card.add(lblStatus, c);

        // ── Hint ──────────────────────────────────────────────────────────
        c.gridy = 9;
        JLabel hint = new JLabel("<html><center>Admin: warden / admin@99<br>Student: arjun / pass123</center></html>",
                                  JLabel.CENTER);
        hint.setFont(UIConstants.FONT_SMALL_ITALIC);
        hint.setForeground(UIConstants.TEXT_SECONDARY);
        card.add(hint, c);

        // ── Add card to this panel ────────────────────────────────────────
        add(card, gbc);

        // Enter key triggers login
        tfPassword.addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        String username = tfUsername.getText().trim();
        String password = new String(tfPassword.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            lblStatus.setText("Please enter username and password.");
            return;
        }

        // Try admin
        if (adminUser.login(username, password)) {
            parentFrame.onLoginSuccess(adminUser, "ADMIN");
            return;
        }

        // Try student
        if (studentUser.login(username, password)) {
            parentFrame.onLoginSuccess(studentUser, "STUDENT");
            return;
        }

        lblStatus.setText("Invalid credentials. Please try again.");
        tfPassword.setText("");
    }
}
