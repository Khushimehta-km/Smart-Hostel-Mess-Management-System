package com.hostel.foodwaste.ui;

import com.hostel.foodwaste.models.DailyWasteRecord;
import com.hostel.foodwaste.services.DataRepository;
import com.hostel.foodwaste.services.SuggestionService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Enhanced DashboardPanel — Intelligent Food Data Tracking.
 */
public class DashboardPanel extends JPanel {

    private static final double PER_CAPITA_KG = 0.5;
    private JTextField tfFoodPrepared, tfStudentsAte, tfDate;
    private JLabel lblConsumed, lblWasted, lblEfficiency, lblPrediction;
    private JProgressBar pbConsumed, pbWasted;
    private JPanel chartContainer;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel statPreparedVal, statConsumedVal, statWastedVal, statEfficiencyVal;
    private JTextArea taSuggestions;

    public DashboardPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UIConstants.BG_MAIN);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        add(buildTopSection(), BorderLayout.NORTH);
        add(buildCenterSection(), BorderLayout.CENTER);
        
        refreshDashboard();
    }

    private JPanel buildTopSection() {
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setOpaque(false);

        // Stat Cards
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 10, 0));
        statsRow.setOpaque(false);
        JPanel c1 = UIConstants.createStatCard("0.00", "Total Prepared (kg)", UIConstants.ACCENT_BLUE);
        statPreparedVal = (JLabel)((BorderLayout)c1.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        statsRow.add(c1);
        JPanel c2 = UIConstants.createStatCard("0.00", "Total Consumed (kg)", UIConstants.ACCENT_GREEN);
        statConsumedVal = (JLabel)((BorderLayout)c2.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        statsRow.add(c2);
        JPanel c3 = UIConstants.createStatCard("0.00", "Total Wasted (kg)", UIConstants.ACCENT_RED);
        statWastedVal = (JLabel)((BorderLayout)c3.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        statsRow.add(c3);
        JPanel c4 = UIConstants.createStatCard("0%", "Efficiency", UIConstants.PRIMARY);
        statEfficiencyVal = (JLabel)((BorderLayout)c4.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        statsRow.add(c4);
        top.add(statsRow, BorderLayout.NORTH);

        // Input Form
        JPanel form = UIConstants.createCard();
        form.setLayout(new GridBagLayout());
        form.setBorder(UIConstants.createThemedTitledBorder("Daily Food Analytics", UIConstants.PRIMARY));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx=0; g.gridy=0;
        form.add(label("Date (YYYY-MM-DD):"), g);
        g.gridx=1; g.weightx=1;
        tfDate = new JTextField(LocalDate.now().toString());
        form.add(tfDate, g);
        
        g.gridx=2; g.weightx=0;
        form.add(label("Food Prepared (kg):"), g);
        g.gridx=3; g.weightx=1;
        tfFoodPrepared = new JTextField(10);
        form.add(tfFoodPrepared, g);

        g.gridx=4; g.weightx=0;
        form.add(label("Students Who Ate:"), g);
        g.gridx=5; g.weightx=1;
        tfStudentsAte = new JTextField(10);
        form.add(tfStudentsAte, g);

        g.gridx=6; g.weightx=0;
        JButton btn = UIConstants.createStyledButton("Save & Analyze", UIConstants.BTN_SUCCESS);
        btn.addActionListener(e -> handleCalculate());
        form.add(btn, g);

        // Prediction and Progress
        g.gridx=0; g.gridy=1; g.gridwidth=3;
        lblPrediction = new JLabel("Predicted Required: -- kg");
        lblPrediction.setFont(UIConstants.FONT_BODY_BOLD);
        lblPrediction.setForeground(UIConstants.ACCENT_BLUE);
        form.add(lblPrediction, g);
        
        g.gridx=3; g.gridwidth=2;
        lblWasted = new JLabel("Wasted Today: --");
        lblWasted.setFont(UIConstants.FONT_BODY_BOLD);
        lblWasted.setForeground(UIConstants.ACCENT_RED);
        form.add(lblWasted, g);

        g.gridx=5; g.gridwidth=2;
        lblEfficiency = new JLabel("Efficiency Today: --");
        lblEfficiency.setFont(UIConstants.FONT_BODY_BOLD);
        lblEfficiency.setForeground(UIConstants.PRIMARY);
        form.add(lblEfficiency, g);

        g.gridx=0; g.gridy=2; g.gridwidth=3;
        pbConsumed = makeProgressBar("Consumed: 0%", UIConstants.CHART_GREEN);
        form.add(pbConsumed, g);
        g.gridx=3; g.gridwidth=4;
        pbWasted = makeProgressBar("Wasted: 0%", UIConstants.CHART_RED);
        form.add(pbWasted, g);

        top.add(form, BorderLayout.CENTER);
        return top;
    }

    private JPanel buildCenterSection() {
        JPanel center = new JPanel(new GridLayout(1, 2, 10, 0));
        center.setOpaque(false);

        // Left: Suggestions and History
        JPanel left = new JPanel(new BorderLayout(0, 10));
        left.setOpaque(false);

        JPanel sugCard = UIConstants.createCard();
        sugCard.setLayout(new BorderLayout());
        sugCard.setBorder(UIConstants.createThemedTitledBorder("Smart Suggestions", UIConstants.ACCENT_BLUE));
        taSuggestions = new JTextArea(4, 20);
        taSuggestions.setEditable(false);
        taSuggestions.setFont(UIConstants.FONT_BODY);
        taSuggestions.setBackground(new Color(245, 250, 255));
        sugCard.add(new JScrollPane(taSuggestions), BorderLayout.CENTER);
        left.add(sugCard, BorderLayout.NORTH);

        JPanel tc = UIConstants.createCard();
        tc.setLayout(new BorderLayout());
        JLabel tl = new JLabel("  Recent Tracking History");
        tl.setFont(UIConstants.FONT_HEADING);
        tl.setForeground(UIConstants.PRIMARY);
        tc.add(tl, BorderLayout.NORTH);
        String[] cols = {"Date", "Prepared", "Ate", "Wasted", "Efficiency"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r,int c){return false;}
        };
        table = new JTable(tableModel);
        UIConstants.styleTable(table);
        tc.add(new JScrollPane(table), BorderLayout.CENTER);
        left.add(tc, BorderLayout.CENTER);
        
        center.add(left);

        // Right: Visualizations
        JPanel right = UIConstants.createCard();
        right.setLayout(new BorderLayout());
        right.setBorder(UIConstants.createThemedTitledBorder("Data Visualization", UIConstants.PRIMARY));
        
        chartContainer = new JPanel(new GridLayout(2, 1, 5, 5));
        chartContainer.setOpaque(false);
        right.add(chartContainer, BorderLayout.CENTER);
        
        center.add(right);
        return center;
    }

    private void handleCalculate() {
        try {
            String date = tfDate.getText().trim();
            double prepared = Double.parseDouble(tfFoodPrepared.getText().trim());
            int students = Integer.parseInt(tfStudentsAte.getText().trim());
            
            if (prepared <= 0 || students < 0) { warn("Enter valid positive values."); return; }
            
            double consumed = Math.min(students * PER_CAPITA_KG, prepared);
            double wasted = prepared - consumed;
            double eff = (prepared > 0) ? (consumed / prepared) * 100 : 0;

            DailyWasteRecord record = new DailyWasteRecord(date, prepared, consumed, wasted, students, eff);
            DataRepository.getInstance().addWasteRecord(record);

            // Alerts
            if (eff < 70) {
                JOptionPane.showMessageDialog(this, "High Waste Alert! Efficiency is below 70%.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            if (wasted > 20) {
                JOptionPane.showMessageDialog(this, "Donation Ready! Edible waste exceeds 20kg.", "Notification", JOptionPane.INFORMATION_MESSAGE);
            }

            refreshDashboard();
            tfFoodPrepared.setText(""); tfStudentsAte.setText("");
        } catch(NumberFormatException ex) { warn("Enter valid numbers."); }
    }

    private void refreshDashboard() {
        DataRepository repo = DataRepository.getInstance();
        List<DailyWasteRecord> records = repo.getWasteRecords();

        // Update Stats
        statPreparedVal.setText(String.format("%.1f", repo.getTotalPrepared()));
        statConsumedVal.setText(String.format("%.1f", repo.getTotalConsumed()));
        statWastedVal.setText(String.format("%.1f", repo.getTotalWasted()));
        double totalEff = (repo.getTotalPrepared() > 0) ? (repo.getTotalConsumed() / repo.getTotalPrepared()) * 100 : 0;
        statEfficiencyVal.setText(String.format("%.0f%%", totalEff));

        // Update Table
        tableModel.setRowCount(0);
        for (int i = Math.max(0, records.size() - 5); i < records.size(); i++) {
            DailyWasteRecord r = records.get(i);
            tableModel.addRow(new Object[]{
                r.getDate(), String.format("%.1f", r.getPreparedKg()), r.getBookedStudents(),
                String.format("%.1f", r.getWastedKg()), String.format("%.0f%%", r.getEfficiency())
            });
        }

        // Update Suggestions
        if (!records.isEmpty()) {
            DailyWasteRecord latest = records.get(records.size() - 1);
            List<String> sugs = SuggestionService.generateSuggestions(latest, records);
            taSuggestions.setText(String.join("\n\u2022 ", sugs));
            
            lblWasted.setText(String.format("Wasted Today: %.1f kg", latest.getWastedKg()));
            lblEfficiency.setText(String.format("Efficiency Today: %.1f%%", latest.getEfficiency()));
            pbConsumed.setValue((int)latest.getEfficiency()); pbConsumed.setString("Consumed: "+(int)latest.getEfficiency()+"%");
            pbWasted.setValue(100-(int)latest.getEfficiency()); pbWasted.setString("Wasted: "+(100-(int)latest.getEfficiency())+"%");
            
            double pred = SuggestionService.calculateSuggestedQuantity(latest.getBookedStudents(), PER_CAPITA_KG);
            lblPrediction.setText(String.format("Predicted Required: %.1f kg", pred));
        }

        // Update Charts
        chartContainer.removeAll();
        if (records.size() > 0) {
            // Triple Bar Chart: Prepared vs Consumed vs Wasted
            int count = Math.min(records.size(), 5);
            double[] prepArr = new double[count];
            double[] consArr = new double[count];
            double[] wastArr = new double[count];
            String[] labels = new String[count];
            for(int i=0; i<count; i++) {
                DailyWasteRecord r = records.get(records.size() - count + i);
                prepArr[i] = r.getPreparedKg();
                consArr[i] = r.getConsumedKg();
                wastArr[i] = r.getWastedKg();
                labels[i] = r.getDate().substring(5);
            }
            chartContainer.add(ChartFactory.createTripleBarChart("Food Metrics", prepArr, consArr, wastArr, labels));
            
            // Line Graph: Efficiency Trend
            List<Double> effs = records.stream().map(DailyWasteRecord::getEfficiency).collect(Collectors.toList());
            chartContainer.add(ChartFactory.createLineGraph("Efficiency Trend (%)", effs, UIConstants.ACCENT_GREEN));
        }
        chartContainer.revalidate();
        chartContainer.repaint();
    }

    private JLabel label(String t){JLabel l=new JLabel(t);l.setFont(UIConstants.FONT_BODY);return l;}
    private JProgressBar makeProgressBar(String s,Color c){
        JProgressBar p=new JProgressBar(0,100);p.setStringPainted(true);p.setString(s);
        p.setForeground(c);p.setBackground(new Color(230,235,240));
        p.setPreferredSize(new Dimension(0,22));return p;
    }
    private void warn(String m){JOptionPane.showMessageDialog(this,m,"Input Error",JOptionPane.WARNING_MESSAGE);}
}
