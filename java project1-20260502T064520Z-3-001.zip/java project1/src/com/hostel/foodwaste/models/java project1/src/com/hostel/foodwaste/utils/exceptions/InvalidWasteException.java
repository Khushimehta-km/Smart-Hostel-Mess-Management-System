package com.hostel.foodwaste.utils.exceptions;

/**
 * Custom Exception: InvalidWasteException
 * Thrown when invalid waste data is provided.
 */
public class InvalidWasteException extends Exception {

    private String fieldName;

    public InvalidWasteException(String message) {
        super(message);
        this.fieldName = "unknown";
    }

    public InvalidWasteException(String message, String fieldName) {
        super(message);
        this.fieldName = fieldName;
    }

    public String getFieldName() { return fieldName; }

    @Override
    public String toString() {
        return "InvalidWasteException [field=" + fieldName + "]: " + getMessage();
    }
}
