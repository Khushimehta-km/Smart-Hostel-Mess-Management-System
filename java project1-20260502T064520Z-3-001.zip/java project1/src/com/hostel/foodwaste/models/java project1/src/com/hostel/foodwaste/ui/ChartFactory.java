package com.hostel.foodwaste.ui;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

/**
 * Reusable Custom Chart components using Graphics2D.
 */
public class ChartFactory {

    public static JPanel createTripleBarChart(String title, double[] prepared, double[] consumed, double[] wasted, String[] labels) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth(), h = getHeight();
                int pad = 40, cH = h - pad * 2, cW = w - pad * 2;

                if (prepared.length == 0) return;

                double max = 0;
                for (int i=0; i<prepared.length; i++) {
                    max = Math.max(max, Math.max(prepared[i], Math.max(consumed[i], wasted[i])));
                }
                if (max == 0) max = 1;

                int groupW = cW / prepared.length;
                int barW = Math.max(4, (groupW - 20) / 3);
                
                for (int i = 0; i < prepared.length; i++) {
                    int xBase = pad + i * groupW + 10;
                    
                    // Prepared
                    int hP = (int) ((prepared[i] / max) * cH);
                    g2.setColor(UIConstants.ACCENT_BLUE);
                    g2.fillRoundRect(xBase, h - pad - hP, barW, hP, 5, 5);
                    
                    // Consumed
                    int hC = (int) ((consumed[i] / max) * cH);
                    g2.setColor(UIConstants.ACCENT_GREEN);
                    g2.fillRoundRect(xBase + barW + 2, h - pad - hC, barW, hC, 5, 5);
                    
                    // Wasted
                    int hW = (int) ((wasted[i] / max) * cH);
                    g2.setColor(UIConstants.ACCENT_RED);
                    g2.fillRoundRect(xBase + (barW + 2) * 2, h - pad - hW, barW, hW, 5, 5);

                    g2.setColor(UIConstants.TEXT_SECONDARY);
                    g2.setFont(UIConstants.FONT_SMALL);
                    g2.drawString(labels[i], xBase, h - pad + 15);
                }
                
                // Legend
                g2.setFont(UIConstants.FONT_SMALL);
                int lx = w - 120, ly = 10;
                Color[] cs = {UIConstants.ACCENT_BLUE, UIConstants.ACCENT_GREEN, UIConstants.ACCENT_RED};
                String[] ls = {"Prep", "Cons", "Waste"};
                for(int j=0; j<3; j++) {
                    g2.setColor(cs[j]); g2.fillRect(lx, ly + j*15, 10, 10);
                    g2.setColor(UIConstants.TEXT_PRIMARY); g2.drawString(ls[j], lx+15, ly + j*15 + 9);
                }
            }
        };
    }

    public static JPanel createPieChart(String title, double[] values, String[] labels, Color[] colors) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth(), h = getHeight();
                int size = Math.min(w, h) - 60;
                int x = (w - size) / 2, y = (h - size) / 2;

                double total = 0;
                for (double v : values) total += v;
                if (total == 0) return;

                int startAngle = 0;
                for (int i = 0; i < values.length; i++) {
                    int arcAngle = (int) Math.round((values[i] / total) * 360);
                    g2.setColor(colors[i % colors.length]);
                    g2.fillArc(x, y, size, size, startAngle, arcAngle);
                    
                    // Legend
                    int lx = w - 100, ly = 20 + i * 20;
                    g2.fillRect(lx, ly, 12, 12);
                    g2.setColor(UIConstants.TEXT_PRIMARY);
                    g2.setFont(UIConstants.FONT_SMALL);
                    g2.drawString(labels[i], lx + 16, ly + 10);
                    
                    startAngle += arcAngle;
                    g2.setColor(colors[i % colors.length]);
                }
            }
        };
    }

    public static JPanel createLineGraph(String title, List<Double> dataPoints, Color color) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth(), h = getHeight();
                int pad = 40, cH = h - pad * 2, cW = w - pad * 2;

                if (dataPoints.size() < 2) {
                    g2.drawString("Need at least 2 points", pad, h/2);
                    return;
                }

                double max = dataPoints.stream().mapToDouble(d -> d).max().orElse(1);
                if (max == 0) max = 1;

                g2.setColor(new Color(230, 230, 230));
                for(int i=0; i<=5; i++) {
                    int y = h - pad - (i * cH / 5);
                    g2.drawLine(pad, y, w - pad, y);
                }

                g2.setColor(color);
                g2.setStroke(new BasicStroke(2.5f));
                
                int stepX = cW / (dataPoints.size() - 1);
                for (int i = 0; i < dataPoints.size() - 1; i++) {
                    int x1 = pad + i * stepX;
                    int y1 = h - pad - (int)((dataPoints.get(i) / max) * cH);
                    int x2 = pad + (i + 1) * stepX;
                    int y2 = h - pad - (int)((dataPoints.get(i + 1) / max) * cH);
                    g2.drawLine(x1, y1, x2, y2);
                    g2.fillOval(x1-3, y1-3, 6, 6);
                }
                int lastX = pad + (dataPoints.size()-1)*stepX;
                int lastY = h - pad - (int)((dataPoints.get(dataPoints.size()-1) / max) * cH);
                g2.fillOval(lastX-3, lastY-3, 6, 6);
            }
        };
    }
}
