package com.hostel.foodwaste.services;

import com.hostel.foodwaste.models.DailyWasteRecord;
import com.hostel.foodwaste.models.SpecialMealRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * Smart Suggestion System logic.
 */
public class SuggestionService {

    public static List<String> generateSuggestions(DailyWasteRecord current, List<DailyWasteRecord> history) {
        List<String> suggestions = new ArrayList<>();

        if (current == null) return suggestions;

        // 1. Waste reduction suggestion
        if (current.getEfficiency() < 70) {
            double suggestedReduction = (current.getWastedKg() / current.getPreparedKg()) * 100;
            suggestions.add(String.format("High waste detected: Reduce next meal preparation by %.0f%%.", suggestedReduction));
        } else if (current.getEfficiency() >= 90) {
            suggestions.add("Excellent efficiency! Maintain current preparation standards.");
        }

        // 2. Special meal demand suggestion
        long specialCount = DataRepository.getInstance().getSpecialMealsByDate(current.getDate()).size();
        if (specialCount > 5) {
            suggestions.add("High sick student count: Increase 'Khichdi' preparation by 20%.");
        }

        // 3. Trend analysis (comparison with history)
        if (history.size() > 1) {
            double avgWasted = history.stream().mapToDouble(DailyWasteRecord::getWastedKg).average().orElse(0);
            if (current.getWastedKg() > avgWasted * 1.5) {
                suggestions.add("Warning: Waste today is 50% higher than weekly average. Investigate menu items.");
            }
        }

        if (suggestions.isEmpty()) {
            suggestions.add("Data analysis in progress... provide more entries for better insights.");
        }

        return suggestions;
    }
    
    public static double calculateSuggestedQuantity(int bookedStudents, double avgPerStudent) {
        // Suggested Food Quantity = Total Booked Students × Average Consumption per Student
        return bookedStudents * avgPerStudent;
    }
}
