package com.hostel.foodwaste.services;

import com.hostel.foodwaste.models.Food;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Class: DonationService
 * Manages donation of surplus food to NGOs or charities.
 * Enhanced with threshold-based donation alerts.
 */
public class DonationService {

    // ── Donation threshold (kg) ──────────────────────────────────────────
    public static final double DONATION_THRESHOLD = 5.0;

    // ── Fields ────────────────────────────────────────────────────────────
    private String       serviceName;
    private List<String> donationLog;
    private double       totalDonatedKg;

    // ── Default Constructor ───────────────────────────────────────────────
    public DonationService() {
        this("Hostel Donation Drive");
    }

    // ── Parameterized Constructor ─────────────────────────────────────────
    public DonationService(String serviceName) {
        this.serviceName    = serviceName;
        this.donationLog    = new ArrayList<>();
        this.totalDonatedKg = 0.0;
    }

    // ── Donate (auto date) ────────────────────────────────────────────────
    public void donate(Food food, double quantityKg, String ngoName) {
        donate(food, quantityKg, ngoName, LocalDate.now().toString());
    }

    // ── Donate (with specific date) ───────────────────────────────────────
    public void donate(Food food, double quantityKg, String ngoName, String date) {
        if (quantityKg <= 0) {
            System.out.println("[DonationService] Invalid quantity. Donation cancelled.");
            return;
        }
        String record = "[Donated] " + food.getName() +
                        " | Qty: " + String.format("%.2f", quantityKg) + " kg" +
                        " -> " + ngoName +
                        " | Date: " + date;
        donationLog.add(record);
        this.totalDonatedKg += quantityKg;
    }

    // ── Donate by name only (convenience) ─────────────────────────────────
    public void donate(String foodName, double quantityKg, String ngoName, String date) {
        Food temp = new Food(foodName, "Donated", quantityKg, "N/A");
        donate(temp, quantityKg, ngoName, date);
    }

    // ── Threshold check ───────────────────────────────────────────────────
    public boolean isEligibleForDonation(double edibleWasteKg) {
        return edibleWasteKg > DONATION_THRESHOLD;
    }

    // ── Get alert message ─────────────────────────────────────────────────
    public String getDonationAlert(double edibleWasteKg) {
        if (isEligibleForDonation(edibleWasteKg)) {
            return "ALERT: " + String.format("%.2f", edibleWasteKg) +
                   " kg of edible food available for donation! (Threshold: " +
                   DONATION_THRESHOLD + " kg)";
        }
        return "Edible waste (" + String.format("%.2f", edibleWasteKg) +
               " kg) is below donation threshold (" + DONATION_THRESHOLD + " kg).";
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public String       getServiceName()    { return serviceName; }
    public double       getTotalDonatedKg() { return totalDonatedKg; }
    public List<String> getDonationLog()    { return new ArrayList<>(donationLog); }
    public int          getTotalDonations() { return donationLog.size(); }

    public void setServiceName(String name) { this.serviceName = name; }
}
