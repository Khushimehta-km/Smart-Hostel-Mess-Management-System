package com.hostel.foodwaste.models;

/**
 * Class: Food
 * Represents a food item tracked in the hostel system.
 *
 * Concepts used:
 *   - private fields (encapsulation)
 *   - default + parameterized constructors
 *   - this keyword for field assignment and constructor chaining
 *   - method overloading (display method)
 */
public class Food {

    // ── Private Fields ────────────────────────────────────────────────────
    private int    foodId;
    private String name;
    private String category;
    private double quantityKg;
    private String expiryDate;

    // ── Default Constructor ───────────────────────────────────────────────
    public Food() {
        this("Unknown", "Uncategorized", 0.0, "N/A");
    }

    // ── Parameterized Constructor (without ID) ────────────────────────────
    public Food(String name, String category, double quantityKg, String expiryDate) {
        this.name       = name;
        this.category   = category;
        this.quantityKg = quantityKg;
        this.expiryDate = expiryDate;
    }

    // ── Full Constructor (with ID) ────────────────────────────────────────
    public Food(int foodId, String name, String category, double quantityKg, String expiryDate) {
        this(name, category, quantityKg, expiryDate);
        this.foodId = foodId;
    }

    // ── Method Overloading: display() ─────────────────────────────────────
    public String display() {
        return "[Food] ID: " + foodId + " | Name: " + name +
               " | Category: " + category + " | Qty: " + quantityKg +
               " kg | Expiry: " + expiryDate;
    }

    public String display(boolean shortFormat) {
        if (shortFormat) {
            return name + " (" + category + ")";
        }
        return display();
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public int    getFoodId()     { return foodId; }
    public String getName()       { return name; }
    public String getCategory()   { return category; }
    public double getQuantityKg() { return quantityKg; }
    public String getExpiryDate() { return expiryDate; }

    // ── Setters ───────────────────────────────────────────────────────────
    public void setFoodId(int foodId)          { this.foodId     = foodId; }
    public void setName(String name)           { this.name       = name; }
    public void setCategory(String category)   { this.category   = category; }
    public void setQuantityKg(double qty)      { this.quantityKg = qty; }
    public void setExpiryDate(String date)     { this.expiryDate = date; }

    @Override
    public String toString() {
        return display();
    }
}
