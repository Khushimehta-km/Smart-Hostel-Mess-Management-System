package com.hostel.foodwaste.services;

import com.hostel.foodwaste.models.Food;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Class: FoodRepository
 * Central store for all Food items in the hostel system.
 */
public class FoodRepository {

    private List<Food> foodList;
    private String     repositoryName;

    public FoodRepository() {
        this("Main Food Store");
    }

    public FoodRepository(String repositoryName) {
        this.repositoryName = repositoryName;
        this.foodList       = new ArrayList<>();
    }

    public void addFood(Food food) {
        if (food == null) {
            System.out.println("[FoodRepository] Cannot add null food item.");
            return;
        }
        if (findById(food.getFoodId()) != null) {
            System.out.println("[FoodRepository] Food with ID " + food.getFoodId() + " already exists.");
            return;
        }
        foodList.add(food);
        System.out.println("[FoodRepository] Added: " + food.display(true));
    }

    public boolean removeFood(int foodId) {
        Iterator<Food> iterator = foodList.iterator();
        while (iterator.hasNext()) {
            Food f = iterator.next();
            if (f.getFoodId() == foodId) {
                iterator.remove();
                System.out.println("[FoodRepository] Removed food with ID: " + foodId);
                return true;
            }
        }
        System.out.println("[FoodRepository] Food ID " + foodId + " not found.");
        return false;
    }

    public Food findById(int foodId) {
        for (Food f : foodList) {
            if (f.getFoodId() == foodId) {
                return f;
            }
        }
        return null;
    }

    public List<Food> findByCategory(String category) {
        List<Food> result = new ArrayList<>();
        for (Food f : foodList) {
            if (f.getCategory().equalsIgnoreCase(category)) {
                result.add(f);
            }
        }
        return result;
    }

    public void displayAll() {
        System.out.println("=== Food Repository [" + repositoryName + "] ===");
        if (foodList.isEmpty()) {
            System.out.println("  No food items stored.");
            return;
        }
        for (Food f : foodList) {
            System.out.println("  " + f.display());
        }
        System.out.println("  Total Items: " + foodList.size());
    }

    public void displayAll(String category) {
        List<Food> filtered = findByCategory(category);
        System.out.println("=== Food Repository [Category: " + category + "] ===");
        if (filtered.isEmpty()) {
            System.out.println("  No items found in category: " + category);
            return;
        }
        for (Food f : filtered) {
            System.out.println("  " + f.display());
        }
        System.out.println("  Total: " + filtered.size() + " item(s)");
    }

    public List<Food> getFoodList()       { return new ArrayList<>(foodList); }
    public int        getTotalFoodCount() { return foodList.size(); }
    public String     getRepositoryName() { return repositoryName; }
}
