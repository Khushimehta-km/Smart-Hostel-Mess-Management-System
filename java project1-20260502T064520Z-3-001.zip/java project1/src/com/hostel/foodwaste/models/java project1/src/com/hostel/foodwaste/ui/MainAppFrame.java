package com.hostel.foodwaste.ui;

import com.hostel.foodwaste.models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * MainAppFrame — Root JFrame with sidebar navigation and CardLayout content.
 * Holds Login screen and all 6 module panels.
 */
public class MainAppFrame extends JFrame {

    private CardLayout cardLayout;
    private JPanel     contentPanel;
    private JPanel     sidebarPanel;
    private JPanel     mainPanel;      // sidebar + content combined
    private JLabel     lblUserInfo;
    private String     currentCard = "Dashboard";

    // Panel references
    private DashboardPanel        dashboardPanel;
    private MealBookingPanel      mealBookingPanel;
    private WasteSegregationPanel wastePanel;
    private CompostingPanel       compostingPanel;
    private DonationPanel         donationPanel;
    private SpecialMealPanel      specialMealPanel;
    private ReportsPanel          reportsPanel;

    // Navigation items
    private static final String[] NAV_ITEMS = {
        "Dashboard", "Meal Booking", "Special Meal", "Waste Segregation",
        "Composting", "Donation", "Reports"
    };
    private static final String[] NAV_ICONS = {
        "\uD83D\uDCCA", "\uD83C\uDF5D", "\uD83E\uDD63", "\u267B\uFE0F",
        "\uD83C\uDF31", "\uD83E\uDD1D", "\uD83D\uDCCB"
    };

    private JLabel[] navLabels;

    public MainAppFrame() {
        setTitle("Smart Hostel Food Waste Management System");
        setSize(1100, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(900, 600));

        // Start with login
        CardLayout rootLayout = new CardLayout();
        JPanel rootPanel = new JPanel(rootLayout);

        LoginPanel loginPanel = new LoginPanel(this);
        rootPanel.add(loginPanel, "Login");

        mainPanel = buildMainPanel();
        rootPanel.add(mainPanel, "Main");

        setContentPane(rootPanel);
        rootLayout.show(rootPanel, "Login");
    }

    /** Called by LoginPanel on successful login */
    public void onLoginSuccess(User user, String role) {
        if (user != null) {
            lblUserInfo.setText("  " + user.getUsername() + " (" + role + ")  ");
        } else {
            lblUserInfo.setText("  Guest  ");
        }

        // Role-Based Access: Students only see Meal Booking and Special Meal
        boolean isAdmin = "ADMIN".equalsIgnoreCase(role) || "Guest".equalsIgnoreCase(role);
        for (int i = 0; i < NAV_ITEMS.length; i++) {
            String name = NAV_ITEMS[i];
            boolean visible = true;
            if (!isAdmin) {
                if (name.equals("Dashboard") || name.equals("Waste Segregation") || 
                    name.equals("Composting") || name.equals("Donation") || name.equals("Reports")) {
                    visible = false;
                }
            }
            navLabels[i].setVisible(visible);
        }

        // Default to first visible tab
        if (!isAdmin) {
            navigateTo("Meal Booking", 1);
        } else {
            navigateTo("Dashboard", 0);
        }

        CardLayout cl = (CardLayout) getContentPane().getLayout();
        cl.show(getContentPane(), "Main");
    }

    private JPanel buildMainPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // ── Header ────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIConstants.PRIMARY_DARK);
        header.setPreferredSize(new Dimension(0, 50));

        JLabel title = new JLabel(
                "  \uD83C\uDF3F Smart Hostel Food Waste Manager");
        title.setFont(UIConstants.FONT_TITLE);
        title.setForeground(UIConstants.TEXT_WHITE);
        header.add(title, BorderLayout.WEST);

        lblUserInfo = new JLabel("  Guest  ");
        lblUserInfo.setFont(UIConstants.FONT_BODY);
        lblUserInfo.setForeground(UIConstants.TEXT_LIGHT);
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        userPanel.setOpaque(false);
        JButton btnLogout = new JButton("Logout");
        btnLogout.setFont(UIConstants.FONT_SMALL);
        btnLogout.setForeground(UIConstants.TEXT_LIGHT);
        btnLogout.setBackground(UIConstants.PRIMARY_DARK);
        btnLogout.setBorderPainted(false);
        btnLogout.setFocusPainted(false);
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.addActionListener(e -> {
            CardLayout cl = (CardLayout) getContentPane().getLayout();
            cl.show(getContentPane(), "Login");
        });
        userPanel.add(lblUserInfo);
        userPanel.add(btnLogout);
        header.add(userPanel, BorderLayout.EAST);
        panel.add(header, BorderLayout.NORTH);

        // ── Sidebar ───────────────────────────────────────────────────────
        sidebarPanel = buildSidebar();
        panel.add(sidebarPanel, BorderLayout.WEST);

        // ── Content Area (CardLayout) ─────────────────────────────────────
        cardLayout   = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(UIConstants.BG_MAIN);

        dashboardPanel   = new DashboardPanel();
        mealBookingPanel = new MealBookingPanel();
        specialMealPanel = new SpecialMealPanel();
        wastePanel       = new WasteSegregationPanel();
        compostingPanel  = new CompostingPanel();
        donationPanel    = new DonationPanel();
        reportsPanel     = new ReportsPanel();

        contentPanel.add(dashboardPanel,   "Dashboard");
        contentPanel.add(mealBookingPanel, "Meal Booking");
        contentPanel.add(specialMealPanel, "Special Meal");
        contentPanel.add(wastePanel,       "Waste Segregation");
        contentPanel.add(compostingPanel,  "Composting");
        contentPanel.add(donationPanel,    "Donation");
        contentPanel.add(reportsPanel,     "Reports");

        panel.add(contentPanel, BorderLayout.CENTER);

        // ── Footer ────────────────────────────────────────────────────────
        JLabel footer = new JLabel(
                "  Hostel Food Waste Management System  |  College Project  ",
                JLabel.CENTER);
        footer.setFont(UIConstants.FONT_SMALL_ITALIC);
        footer.setForeground(UIConstants.TEXT_SECONDARY);
        footer.setBorder(BorderFactory.createMatteBorder(
                1, 0, 0, 0, new Color(220, 225, 230)));
        footer.setPreferredSize(new Dimension(0, 28));
        panel.add(footer, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UIConstants.BG_SIDEBAR);
        sidebar.setPreferredSize(
                new Dimension(UIConstants.SIDEBAR_WIDTH, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        navLabels = new JLabel[NAV_ITEMS.length];

        for (int i = 0; i < NAV_ITEMS.length; i++) {
            final String name = NAV_ITEMS[i];
            final int idx = i;

            JLabel lbl = new JLabel(
                    "  " + NAV_ICONS[i] + "  " + name);
            lbl.setFont(UIConstants.FONT_SIDEBAR);
            lbl.setForeground(UIConstants.TEXT_LIGHT);
            lbl.setOpaque(true);
            lbl.setBackground(UIConstants.BG_SIDEBAR);
            lbl.setMaximumSize(new Dimension(
                    UIConstants.SIDEBAR_WIDTH, 44));
            lbl.setPreferredSize(new Dimension(
                    UIConstants.SIDEBAR_WIDTH, 44));
            lbl.setCursor(
                    Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            lbl.setBorder(BorderFactory.createEmptyBorder(
                    0, 12, 0, 0));

            lbl.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    navigateTo(name, idx);
                }
                public void mouseEntered(MouseEvent e) {
                    if (!name.equals(currentCard))
                        lbl.setBackground(UIConstants.BG_SIDEBAR_HOVER);
                }
                public void mouseExited(MouseEvent e) {
                    if (!name.equals(currentCard))
                        lbl.setBackground(UIConstants.BG_SIDEBAR);
                }
            });

            navLabels[i] = lbl;
            sidebar.add(lbl);
        }

        // Highlight first item
        navLabels[0].setBackground(UIConstants.BG_SIDEBAR_ACTIVE);
        navLabels[0].setFont(UIConstants.FONT_SIDEBAR_BOLD);

        return sidebar;
    }

    private void navigateTo(String name, int idx) {
        currentCard = name;
        cardLayout.show(contentPanel, name);

        // Update sidebar highlighting
        for (int i = 0; i < navLabels.length; i++) {
            if (i == idx) {
                navLabels[i].setBackground(UIConstants.BG_SIDEBAR_ACTIVE);
                navLabels[i].setFont(UIConstants.FONT_SIDEBAR_BOLD);
            } else {
                navLabels[i].setBackground(UIConstants.BG_SIDEBAR);
                navLabels[i].setFont(UIConstants.FONT_SIDEBAR);
            }
        }
    }

    // ── Entry Point ───────────────────────────────────────────────────────
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            MainAppFrame frame = new MainAppFrame();
            frame.setVisible(true);
        });
    }
}
