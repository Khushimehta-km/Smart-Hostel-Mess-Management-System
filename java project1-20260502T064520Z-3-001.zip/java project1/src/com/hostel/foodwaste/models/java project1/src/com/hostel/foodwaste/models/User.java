package com.hostel.foodwaste.models;

/**
 * Abstract Class: User
 * Base class for all users (Student, Admin) in the system.
 */
public abstract class User {

    private   int    userId;
    private   String username;
    private   String password;
    protected String role;

    public User() {
        this(0, "guest", "guest@123", "UNKNOWN");
    }

    public User(int userId, String username, String password, String role) {
        this.userId   = userId;
        this.username = username;
        this.password = password;
        this.role     = role;
    }

    public abstract String getDashboardGreeting();

    public boolean login(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    public boolean login(String username) {
        return this.username.equals(username);
    }

    public void logout() {
        System.out.println(this.username + " has logged out successfully.");
    }

    public int    getUserId()   { return userId; }
    public String getUsername() { return username; }
    public String getRole()     { return role; }

    public void setUserId(int userId)        { this.userId   = userId; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }

    @Override
    public String toString() {
        return "[User] ID: " + userId + " | Username: " + username + " | Role: " + role;
    }
}
