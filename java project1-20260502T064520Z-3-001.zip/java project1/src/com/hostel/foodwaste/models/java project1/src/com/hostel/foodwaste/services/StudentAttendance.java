package com.hostel.foodwaste.services;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Class: StudentAttendance
 * Tracks daily meal attendance for hostel students using HashMap + HashSet.
 */
public class StudentAttendance {

    private Map<String, Boolean> attendanceMap;
    private Set<String> mealSkippers;
    private String mealSession;

    public StudentAttendance() {
        this("Lunch");
    }

    public StudentAttendance(String mealSession) {
        this.mealSession   = mealSession;
        this.attendanceMap = new HashMap<>();
        this.mealSkippers  = new HashSet<>();
    }

    public void markAttendance(String studentId, boolean isPresent) {
        attendanceMap.put(studentId, isPresent);
        if (!isPresent) {
            mealSkippers.add(studentId);
        } else {
            mealSkippers.remove(studentId);
        }
    }

    public void markAttendance(String studentId) {
        markAttendance(studentId, true);
    }

    public void removeStudent(String studentId) {
        attendanceMap.remove(studentId);
        mealSkippers.remove(studentId);
    }

    public boolean isPresent(String studentId) {
        if (!attendanceMap.containsKey(studentId)) return false;
        return attendanceMap.get(studentId);
    }

    public int getPresentCount() {
        int count = 0;
        for (boolean status : attendanceMap.values()) {
            if (status) count++;
        }
        return count;
    }

    public int getAbsentCount() {
        return mealSkippers.size();
    }

    public String      getMealSession()    { return mealSession; }
    public Set<String>  getMealSkippers()  { return new HashSet<>(mealSkippers); }
    public int          getTotalTracked()  { return attendanceMap.size(); }

    public Map<String, Boolean> getAttendanceMap() {
        return new HashMap<>(attendanceMap);
    }
}
