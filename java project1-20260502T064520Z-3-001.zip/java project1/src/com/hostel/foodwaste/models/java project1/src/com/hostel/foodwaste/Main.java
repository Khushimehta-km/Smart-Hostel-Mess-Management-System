package com.hostel.foodwaste;

import com.hostel.foodwaste.ui.MainAppFrame;

import javax.swing.*;

/**
 * Main.java — Entry point for Hostel Food Waste Management System (GUI).
 * Launches the Swing application on the Event Dispatch Thread.
 */
public class Main {

    public static void main(String[] args) {
        // Set system look and feel for native appearance
        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        // Launch the GUI on the EDT
        SwingUtilities.invokeLater(() -> {
            MainAppFrame frame = new MainAppFrame();
            frame.setVisible(true);
        });
    }
}
