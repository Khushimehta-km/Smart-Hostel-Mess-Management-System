package com.hostel.foodwaste.ui;

import com.hostel.foodwaste.models.DailyWasteRecord;
import com.hostel.foodwaste.services.DataRepository;
import com.hostel.foodwaste.utils.WasteFileHandler;
import com.hostel.foodwaste.utils.exceptions.InvalidWasteException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

/**
 * Enhanced ReportsPanel — Data-Driven Insights and Filtering.
 */
public class ReportsPanel extends JPanel {

    private JLabel statPrepared, statConsumed, statWasted, statEfficiency;
    private JLabel statBooked, statDonated, statFertilizer;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblStatus;
    private JTextField tfFilterDate;
    private JPanel pieChartPanel;

    public ReportsPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UIConstants.BG_MAIN);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        add(buildTopSection(), BorderLayout.NORTH);
        add(buildCenterSection(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
        
        refreshReport();
    }

    private JPanel buildTopSection() {
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setOpaque(false);

        JPanel headerRow = new JPanel(new BorderLayout());
        headerRow.setOpaque(false);
        JLabel title = UIConstants.createHeaderLabel("System Performance Analytics");
        headerRow.add(title, BorderLayout.WEST);
        
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        filterPanel.setOpaque(false);
        filterPanel.add(new JLabel("Filter by Date: "));
        tfFilterDate = new JTextField(LocalDate.now().toString(), 10);
        filterPanel.add(tfFilterDate);
        JButton btnFilter = UIConstants.createStyledButton("Filter", UIConstants.BTN_INFO);
        btnFilter.addActionListener(e -> filterData());
        filterPanel.add(btnFilter);
        headerRow.add(filterPanel, BorderLayout.EAST);
        
        top.add(headerRow, BorderLayout.NORTH);

        // Stat cards
        JPanel stats = new JPanel(new GridLayout(2, 4, 10, 10));
        stats.setOpaque(false);

        stats.add(createReportStat("Food Prepared", UIConstants.ACCENT_BLUE, statPrepared = new JLabel("0.00 kg")));
        stats.add(createReportStat("Food Consumed", UIConstants.ACCENT_GREEN, statConsumed = new JLabel("0.00 kg")));
        stats.add(createReportStat("Food Wasted", UIConstants.ACCENT_RED, statWasted = new JLabel("0.00 kg")));
        stats.add(createReportStat("Efficiency Score", UIConstants.PRIMARY, statEfficiency = new JLabel("0%")));
        stats.add(createReportStat("Meals Booked", UIConstants.ACCENT_ORANGE, statBooked = new JLabel("0")));
        stats.add(createReportStat("Food Donated", UIConstants.ACCENT_PINK, statDonated = new JLabel("0.00 kg")));
        stats.add(createReportStat("Fertilizer (kg)", UIConstants.ACCENT_PURPLE, statFertilizer = new JLabel("0.00")));
        
        top.add(stats, BorderLayout.CENTER);

        // Buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        btnRow.setOpaque(false);
        JButton btnRefresh = UIConstants.createStyledButton("Refresh All", UIConstants.BTN_INFO);
        btnRefresh.addActionListener(e -> refreshReport());
        btnRow.add(btnRefresh);
        JButton btnExport = UIConstants.createStyledButton("Export Report (.txt)", UIConstants.BTN_SUCCESS);
        btnExport.addActionListener(e -> exportToFile());
        btnRow.add(btnExport);
        top.add(btnRow, BorderLayout.SOUTH);

        return top;
    }

    private JPanel createReportStat(String label, Color color, JLabel valLabel) {
        JPanel card = UIConstants.createCard();
        card.setLayout(new BorderLayout(5, 5));
        valLabel.setFont(UIConstants.FONT_SUBTITLE);
        valLabel.setForeground(color);
        valLabel.setHorizontalAlignment(JLabel.CENTER);
        JLabel l = new JLabel(label, JLabel.CENTER);
        l.setFont(UIConstants.FONT_SMALL);
        card.add(valLabel, BorderLayout.CENTER);
        card.add(l, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildCenterSection() {
        JPanel center = new JPanel(new GridLayout(1, 2, 10, 0));
        center.setOpaque(false);

        JPanel tc = UIConstants.createCard();
        tc.setLayout(new BorderLayout());
        tc.setBorder(UIConstants.createThemedTitledBorder("Detailed Waste Log", UIConstants.PRIMARY));

        String[] cols = {"Date", "Prepared", "Consumed", "Wasted", "Efficiency", "Rating"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UIConstants.styleTable(table);
        tc.add(new JScrollPane(table), BorderLayout.CENTER);
        center.add(tc);
        
        pieChartPanel = UIConstants.createCard();
        pieChartPanel.setLayout(new BorderLayout());
        pieChartPanel.setBorder(UIConstants.createThemedTitledBorder("Waste Distribution (Edible vs Inedible)", UIConstants.ACCENT_RED));
        center.add(pieChartPanel);

        return center;
    }

    private JLabel buildStatusBar() {
        lblStatus = new JLabel("  System ready.");
        lblStatus.setFont(UIConstants.FONT_SMALL_ITALIC);
        lblStatus.setForeground(UIConstants.TEXT_SECONDARY);
        return lblStatus;
    }

    private void filterData() {
        String date = tfFilterDate.getText().trim();
        DailyWasteRecord record = DataRepository.getInstance().getRecordByDate(date);
        if (record != null) {
            updateStatsFromRecord(record);
            setStatus("Data found for " + date, UIConstants.ACCENT_GREEN);
        } else {
            setStatus("No data found for " + date, UIConstants.ACCENT_RED);
        }
    }

    private void updateStatsFromRecord(DailyWasteRecord r) {
        statPrepared.setText(String.format("%.2f kg", r.getPreparedKg()));
        statConsumed.setText(String.format("%.2f kg", r.getConsumedKg()));
        statWasted.setText(String.format("%.2f kg", r.getWastedKg()));
        statBooked.setText(String.valueOf(r.getBookedStudents()));
        statEfficiency.setText(String.format("%.1f%%", r.getEfficiency()));
        statDonated.setText(String.format("%.2f kg", r.getDonatedKg()));
        statFertilizer.setText(String.format("%.2f", r.getFertilizerKg()));
        
        updatePieChart(r);
    }

    private void updatePieChart(DailyWasteRecord r) {
        pieChartPanel.removeAll();
        double edible = r.getWastedKg() * 0.4; // Sample logic
        double inedible = r.getWastedKg() * 0.6;
        pieChartPanel.add(ChartFactory.createPieChart("Waste Types", 
                new double[]{edible, inedible}, 
                new String[]{"Edible", "Inedible"}, 
                new Color[]{UIConstants.ACCENT_GREEN, UIConstants.ACCENT_RED}));
        pieChartPanel.revalidate();
        pieChartPanel.repaint();
    }

    private void refreshReport() {
        DataRepository repo = DataRepository.getInstance();
        List<DailyWasteRecord> records = repo.getWasteRecords();
        
        tableModel.setRowCount(0);
        for (DailyWasteRecord r : records) {
            String rating = "Poor";
            if (r.getEfficiency() >= 90) rating = "Excellent";
            else if (r.getEfficiency() >= 70) rating = "Good";
            
            tableModel.addRow(new Object[]{
                r.getDate(), r.getPreparedKg(), r.getConsumedKg(), r.getWastedKg(),
                String.format("%.1f%%", r.getEfficiency()), rating
            });
        }
        
        if (!records.isEmpty()) {
            updateStatsFromRecord(records.get(records.size() - 1));
        }
        
        setStatus("Report refreshed.", UIConstants.ACCENT_BLUE);
    }

    private void exportToFile() {
        try {
            String date = tfFilterDate.getText().trim();
            DailyWasteRecord r = DataRepository.getInstance().getRecordByDate(date);
            if (r == null && !DataRepository.getInstance().getWasteRecords().isEmpty()) {
                r = DataRepository.getInstance().getWasteRecords().get(0);
            }
            
            if (r == null) {
                warn("No data available to export.");
                return;
            }

            WasteFileHandler fh = new WasteFileHandler("report_export.txt");
            java.util.ArrayList<String> lines = new java.util.ArrayList<>();
            lines.add("=== SMART HOSTEL FOOD WASTE REPORT ===");
            lines.add("Date: " + r.getDate());
            lines.add("---------------------------------------");
            lines.add("Food Prepared: " + r.getPreparedKg() + " kg");
            lines.add("Food Consumed: " + r.getConsumedKg() + " kg");
            lines.add("Food Wasted:   " + r.getWastedKg() + " kg");
            lines.add("Efficiency:    " + String.format("%.1f%%", r.getEfficiency()));
            lines.add("Booked Students: " + r.getBookedStudents());
            lines.add("Donated:       " + r.getDonatedKg() + " kg");
            lines.add("Fertilizer:    " + r.getFertilizerKg() + " kg");
            lines.add("---------------------------------------");
            lines.add("Suggestion: Please review the Smart Suggestion System for insights.");
            
            fh.saveAllRecords(lines);
            setStatus("Report exported to report_export.txt", UIConstants.ACCENT_GREEN);
            JOptionPane.showMessageDialog(this, "Report exported successfully!");
        } catch (Exception ex) {
            warn("Export failed: " + ex.getMessage());
        }
    }

    private void setStatus(String msg, Color c) {
        lblStatus.setText("  " + msg);
        lblStatus.setForeground(c);
    }
    
    private void warn(String m){JOptionPane.showMessageDialog(this,m,"Report Error",JOptionPane.WARNING_MESSAGE);}
}
