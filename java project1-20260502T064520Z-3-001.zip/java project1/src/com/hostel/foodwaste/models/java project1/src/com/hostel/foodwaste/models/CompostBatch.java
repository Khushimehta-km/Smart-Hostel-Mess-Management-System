package com.hostel.foodwaste.models;

/**
 * Class: CompostBatch
 * Represents a single composting batch — inedible waste converted to fertilizer.
 *
 * Concepts used:
 *   - Encapsulation, constructor chaining
 *   - Calculation logic inside the model
 */
public class CompostBatch {

    // ── Fields ────────────────────────────────────────────────────────────
    private int    batchId;
    private double inputWasteKg;
    private double conversionRatio;     // e.g., 0.3 means 1 kg waste → 0.3 fertilizer units
    private double outputFertilizerUnits;
    private String date;

    // ── Default Constructor ───────────────────────────────────────────────
    public CompostBatch() {
        this(0, 0.0, 0.3, "N/A");
    }

    // ── Parameterized Constructor ─────────────────────────────────────────
    public CompostBatch(int batchId, double inputWasteKg, double conversionRatio, String date) {
        this.batchId              = batchId;
        this.inputWasteKg         = inputWasteKg;
        this.conversionRatio      = conversionRatio;
        this.outputFertilizerUnits = inputWasteKg * conversionRatio;
        this.date                 = date;
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public int    getBatchId()              { return batchId; }
    public double getInputWasteKg()         { return inputWasteKg; }
    public double getConversionRatio()      { return conversionRatio; }
    public double getOutputFertilizerUnits() { return outputFertilizerUnits; }
    public String getDate()                 { return date; }

    // ── Setters ───────────────────────────────────────────────────────────
    public void setBatchId(int batchId)                  { this.batchId = batchId; }
    public void setInputWasteKg(double inputWasteKg)     { this.inputWasteKg = inputWasteKg; }
    public void setConversionRatio(double ratio)         { this.conversionRatio = ratio; }
    public void setDate(String date)                     { this.date = date; }

    // Recalculate output when input changes
    public void recalculate() {
        this.outputFertilizerUnits = this.inputWasteKg * this.conversionRatio;
    }

    @Override
    public String toString() {
        return "Batch#" + batchId +
               " | Input: " + String.format("%.2f", inputWasteKg) + " kg" +
               " | Ratio: " + conversionRatio +
               " | Output: " + String.format("%.2f", outputFertilizerUnits) + " units" +
               " | Date: " + date;
    }
}
