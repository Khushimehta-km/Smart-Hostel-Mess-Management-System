package com.hostel.foodwaste.models;

/**
 * Class: SpecialMealRequest
 * Represents a request for a special diet for a sick student.
 */
public class SpecialMealRequest {
    private int requestId;
    private String studentId;
    private String studentName;
    private String reason;
    private String mealType; // Khichdi, Daliya, Oats, Cornflakes
    private String status;   // Requested, Approved, Served
    private boolean doctorRecommended;
    private String requestDate;

    public SpecialMealRequest(int requestId, String studentId, String studentName, String reason, 
                              String mealType, String status, boolean doctorRecommended, String requestDate) {
        this.requestId = requestId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.reason = reason;
        this.mealType = mealType;
        this.status = status;
        this.doctorRecommended = doctorRecommended;
        this.requestDate = requestDate;
    }

    // Getters and Setters
    public int getRequestId() { return requestId; }
    public void setRequestId(int requestId) { this.requestId = requestId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isDoctorRecommended() { return doctorRecommended; }
    public void setDoctorRecommended(boolean doctorRecommended) { this.doctorRecommended = doctorRecommended; }

    public String getRequestDate() { return requestDate; }
    public void setRequestDate(String requestDate) { this.requestDate = requestDate; }
}
