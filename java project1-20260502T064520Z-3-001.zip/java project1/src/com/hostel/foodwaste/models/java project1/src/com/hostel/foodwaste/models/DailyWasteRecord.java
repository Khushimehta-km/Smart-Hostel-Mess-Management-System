package com.hostel.foodwaste.models;

import java.io.Serializable;

/**
 * Model class for daily food waste and consumption records.
 */
public class DailyWasteRecord implements Serializable {
    private String date;
    private double preparedKg;
    private double consumedKg;
    private double wastedKg;
    private int bookedStudents;
    private double efficiency;
    private double donatedKg;
    private double fertilizerKg;

    public DailyWasteRecord(String date, double preparedKg, double consumedKg, double wastedKg, 
                            int bookedStudents, double efficiency) {
        this.date = date;
        this.preparedKg = preparedKg;
        this.consumedKg = consumedKg;
        this.wastedKg = wastedKg;
        this.bookedStudents = bookedStudents;
        this.efficiency = efficiency;
    }

    // Getters and Setters
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public double getPreparedKg() { return preparedKg; }
    public void setPreparedKg(double preparedKg) { this.preparedKg = preparedKg; }

    public double getConsumedKg() { return consumedKg; }
    public void setConsumedKg(double consumedKg) { this.consumedKg = consumedKg; }

    public double getWastedKg() { return wastedKg; }
    public void setWastedKg(double wastedKg) { this.wastedKg = wastedKg; }

    public int getBookedStudents() { return bookedStudents; }
    public void setBookedStudents(int bookedStudents) { this.bookedStudents = bookedStudents; }

    public double getEfficiency() { return efficiency; }
    public void setEfficiency(double efficiency) { this.efficiency = efficiency; }

    public double getDonatedKg() { return donatedKg; }
    public void setDonatedKg(double donatedKg) { this.donatedKg = donatedKg; }

    public double getFertilizerKg() { return fertilizerKg; }
    public void setFertilizerKg(double fertilizerKg) { this.fertilizerKg = fertilizerKg; }
}
