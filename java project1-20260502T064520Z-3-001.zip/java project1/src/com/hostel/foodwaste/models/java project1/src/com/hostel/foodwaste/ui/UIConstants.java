package com.hostel.foodwaste.ui;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

/**
 * Class: UIConstants
 * Centralized design system for the entire application.
 * Defines colors, fonts, and reusable UI helper methods.
 */
public class UIConstants {

    // ═══════════════════════════════════════════════════════════════════════
    // COLOR PALETTE
    // ═══════════════════════════════════════════════════════════════════════
    
    // ── Primary Colors ────────────────────────────────────────────────────
    public static final Color PRIMARY_DARK    = new Color(20, 60, 80);      // Deep teal
    public static final Color PRIMARY         = new Color(34, 85, 102);     // Teal
    public static final Color PRIMARY_LIGHT   = new Color(56, 128, 150);    // Light teal
    public static final Color PRIMARY_HOVER   = new Color(45, 110, 135);    // Hover teal

    // ── Accent Colors ─────────────────────────────────────────────────────
    public static final Color ACCENT_GREEN    = new Color(46, 160, 67);     // Success green
    public static final Color ACCENT_RED      = new Color(200, 55, 55);     // Error/waste red
    public static final Color ACCENT_ORANGE   = new Color(220, 140, 30);    // Warning orange
    public static final Color ACCENT_BLUE     = new Color(50, 120, 200);    // Info blue
    public static final Color ACCENT_PURPLE   = new Color(130, 80, 180);    // Composting purple
    public static final Color ACCENT_PINK     = new Color(200, 80, 120);    // Donation pink

    // ── Background Colors ─────────────────────────────────────────────────
    public static final Color BG_MAIN         = new Color(240, 244, 248);   // Main background
    public static final Color BG_CARD         = Color.WHITE;                // Card background
    public static final Color BG_SIDEBAR      = new Color(24, 50, 65);     // Sidebar dark
    public static final Color BG_SIDEBAR_HOVER= new Color(35, 70, 90);     // Sidebar hover
    public static final Color BG_SIDEBAR_ACTIVE = new Color(45, 95, 120);  // Sidebar active

    // ── Text Colors ───────────────────────────────────────────────────────
    public static final Color TEXT_PRIMARY     = new Color(10, 15, 20);     // Near black for maximum contrast
    public static final Color TEXT_SECONDARY   = new Color(60, 70, 80);     // Darker muted text
    public static final Color TEXT_WHITE       = Color.WHITE;
    public static final Color TEXT_LIGHT       = new Color(200, 210, 220);  // Light sidebar text

    // ── Table Colors ──────────────────────────────────────────────────────
    public static final Color TABLE_HEADER_BG  = new Color(230, 235, 240);  // Light header background
    public static final Color TABLE_HEADER_FG  = new Color(20, 30, 40);      // Dark header text
    public static final Color TABLE_ALT_ROW    = new Color(248, 250, 252);
    public static final Color TABLE_SELECTION  = new Color(34, 85, 102);    // Stronger selection color
    public static final Color TABLE_GRID       = new Color(210, 215, 220);

    // ── Chart Colors ──────────────────────────────────────────────────────
    public static final Color CHART_GREEN      = new Color(76, 175, 80);
    public static final Color CHART_RED        = new Color(244, 67, 54);
    public static final Color CHART_BLUE       = new Color(33, 150, 243);
    public static final Color CHART_ORANGE     = new Color(255, 152, 0);

    // ═══════════════════════════════════════════════════════════════════════
    // FONTS
    // ═══════════════════════════════════════════════════════════════════════
    public static final Font FONT_TITLE        = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_SUBTITLE     = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font FONT_HEADING      = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_BODY         = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_BODY_BOLD    = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_SMALL        = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_SMALL_ITALIC = new Font("Segoe UI", Font.ITALIC, 11);
    public static final Font FONT_TABLE_HEADER = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_TABLE_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SIDEBAR      = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_SIDEBAR_BOLD = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_CARD_VALUE   = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font FONT_CARD_LABEL   = new Font("Segoe UI", Font.BOLD, 12);

    // ═══════════════════════════════════════════════════════════════════════
    // DIMENSIONS
    // ═══════════════════════════════════════════════════════════════════════
    public static final int SIDEBAR_WIDTH      = 200;
    public static final int CARD_ARC           = 12;

    // ═══════════════════════════════════════════════════════════════════════
    // HELPER METHODS
    // ═══════════════════════════════════════════════════════════════════════

    // ── Button Styles ─────────────────────────────────────────────────────
    public static final Color BTN_SUCCESS      = ACCENT_GREEN;
    public static final Color BTN_INFO         = ACCENT_BLUE;
    public static final Color BTN_WARNING      = ACCENT_ORANGE;
    public static final Color BTN_DANGER       = ACCENT_RED;
    public static final Color BTN_DISABLED     = new Color(180, 185, 190);

    /**
     * Creates a premium, rounded JButton with hover and click effects.
     */
    public static JButton createStyledButton(String text, Color baseColor) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int w = getWidth(), h = getHeight();
                Color bg = getBackground();
                
                if (!isEnabled()) {
                    bg = BTN_DISABLED;
                } else if (getModel().isPressed()) {
                    bg = bg.darker();
                } else if (getModel().isRollover()) {
                    bg = bg.brighter();
                }

                // Shadow/Depth effect
                g2.setColor(new Color(0, 0, 0, 30));
                g2.fillRoundRect(2, 2, w-2, h-2, 10, 10);

                // Main Button Body
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, w-2, h-2, 10, 10);
                
                // Optional Border for visibility
                g2.setColor(bg.darker());
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, w-2, h-2, 10, 10);

                // Text
                FontMetrics fm = g2.getFontMetrics();
                Rectangle r = fm.getStringBounds(getText(), g2).getBounds();
                int x = (w - r.width) / 2 - 1;
                int y = (h - r.height) / 2 + fm.getAscent() - 1;
                
                g2.setFont(getFont());
                g2.setColor(getForeground());
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };

        btn.setBackground(baseColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(FONT_BODY_BOLD);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(btn.getPreferredSize().width + 20, 40));
        
        return btn;
    }

    /**
     * Creates a styled card panel with rounded effect.
     */
    public static JPanel createCard() {
        JPanel card = new JPanel();
        card.setBackground(BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 225, 230), 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        return card;
    }

    /**
     * Creates a summary stat card with a large value and label.
     */
    public static JPanel createStatCard(String value, String label, Color accentColor) {
        JPanel card = createCard();
        card.setLayout(new BorderLayout(5, 5));

        // Color strip at top
        JPanel strip = new JPanel();
        strip.setBackground(accentColor);
        strip.setPreferredSize(new Dimension(0, 4));
        card.add(strip, BorderLayout.NORTH);

        // Value label
        JLabel valLabel = new JLabel(value, JLabel.CENTER);
        valLabel.setFont(FONT_CARD_VALUE);
        valLabel.setForeground(accentColor);
        card.add(valLabel, BorderLayout.CENTER);

        // Description label
        JLabel descLabel = new JLabel(label, JLabel.CENTER);
        descLabel.setFont(FONT_CARD_LABEL);
        descLabel.setForeground(TEXT_SECONDARY);
        card.add(descLabel, BorderLayout.SOUTH);

        return card;
    }

    /**
     * Creates a header label.
     */
    public static JLabel createHeaderLabel(String text) {
        JLabel header = new JLabel(text, JLabel.LEFT);
        header.setFont(FONT_SUBTITLE);
        header.setForeground(PRIMARY_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        return header;
    }

    /**
     * Style a JTable with the application theme.
     */
    public static void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(FONT_TABLE_BODY);
        table.setForeground(TEXT_PRIMARY);
        table.getTableHeader().setFont(FONT_TABLE_HEADER);
        table.getTableHeader().setBackground(TABLE_HEADER_BG);
        table.getTableHeader().setForeground(TABLE_HEADER_FG);
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, TABLE_GRID));
        
        table.setSelectionBackground(TABLE_SELECTION);
        table.setSelectionForeground(Color.WHITE);
        table.setGridColor(TABLE_GRID);
        table.setShowGrid(true);
        table.setIntercellSpacing(new Dimension(1, 1));
    }

    /**
     * Creates a titled border with app theme.
     */
    public static Border createThemedTitledBorder(String title, Color color) {
        return BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(color, 1),
            "  " + title,
            0, 0,
            FONT_HEADING,
            color
        );
    }
}
