package com.hostel.foodwaste.services;

import com.hostel.foodwaste.models.MealBooking;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class: MealBookingService
 * Manages meal bookings using ArrayList<MealBooking>.
 *
 * Features:
 *   - Add/remove bookings
 *   - Filter by meal type
 *   - Count confirmed students per meal
 *   - Suggest food preparation quantity based on bookings
 */
public class MealBookingService {

    // ── Constants ─────────────────────────────────────────────────────────
    private static final double SERVING_SIZE_KG = 0.5;  // per student per meal

    // ── Fields ────────────────────────────────────────────────────────────
    private List<MealBooking> bookings;
    private int nextBookingId;

    // ── Constructor ───────────────────────────────────────────────────────
    public MealBookingService() {
        this.bookings      = new ArrayList<>();
        this.nextBookingId = 1;
    }

    // ── Add a booking ─────────────────────────────────────────────────────
    public MealBooking addBooking(String studentId, String studentName,
                                  String roomNumber, String mealType, String date) {
        MealBooking booking = new MealBooking(
            nextBookingId++, studentId, studentName, roomNumber, mealType, date, true
        );
        bookings.add(booking);
        return booking;
    }

    // ── Remove a booking by ID ────────────────────────────────────────────
    public boolean removeBooking(int bookingId) {
        return bookings.removeIf(b -> b.getBookingId() == bookingId);
    }

    // ── Get bookings by meal type ─────────────────────────────────────────
    public List<MealBooking> getBookingsByMeal(String mealType) {
        List<MealBooking> result = new ArrayList<>();
        for (MealBooking b : bookings) {
            if (b.getMealType().toLowerCase().contains(mealType.toLowerCase())) {
                result.add(b);
            }
        }
        return result;
    }

    // ── Total confirmed for a specific meal ───────────────────────────────
    public int getTotalConfirmed(String mealType) {
        int count = 0;
        for (MealBooking b : bookings) {
            // Check if the mealType string contains the specific meal
            if (b.getMealType().toLowerCase().contains(mealType.toLowerCase()) && b.isConfirmed()) {
                count++;
            }
        }
        return count;
    }

    // ── Total confirmed across all individual meals ──────────────────────
    public int getTotalConfirmed() {
        int count = 0;
        for (MealBooking b : bookings) {
            if (b.isConfirmed()) {
                // Count individual meals in the comma-separated string
                String[] parts = b.getMealType().split(",");
                count += parts.length;
            }
        }
        return count;
    }

    // ── Meal-wise summary ─────────────────────────────────────────────────
    public Map<String, Integer> getMealWiseSummary() {
        Map<String, Integer> summary = new HashMap<>();
        String[] meals = {"Breakfast", "Lunch", "Snacks", "Dinner"};
        for (String meal : meals) {
            summary.put(meal, getTotalConfirmed(meal));
        }
        return summary;
    }

    // ── Suggested food quantity for a meal ─────────────────────────────────
    public double getSuggestedQuantity(String mealType) {
        return getTotalConfirmed(mealType) * SERVING_SIZE_KG;
    }

    // ── Suggested food quantity for all meals ─────────────────────────────
    public double getTotalSuggestedQuantity() {
        return getTotalConfirmed() * SERVING_SIZE_KG;
    }

    // ── Get all bookings ──────────────────────────────────────────────────
    public List<MealBooking> getAllBookings() {
        return new ArrayList<>(bookings);
    }

    // ── Get total count ───────────────────────────────────────────────────
    public int getTotalBookings() {
        return bookings.size();
    }

    // ── Get serving size ──────────────────────────────────────────────────
    public static double getServingSizeKg() {
        return SERVING_SIZE_KG;
    }
}
