package com.hostel.foodwaste.ui;

import com.hostel.foodwaste.models.CompostBatch;
import com.hostel.foodwaste.services.CompostingService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;

/**
 * CompostingPanel — Composting Simulation Module.
 * Takes inedible waste input, converts to fertilizer units,
 * shows animated progress bar and batch history.
 */
public class CompostingPanel extends JPanel {

    private final CompostingService compostService = new CompostingService();
    private JTextField tfWasteInput, tfRatio;
    private JLabel lblOutputUnits, lblStatus;
    private JProgressBar pbProgress;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel statTotalWaste, statTotalFert, statBatches, statRatio;
    private Timer animTimer;

    public CompostingPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UIConstants.BG_MAIN);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        add(buildTopSection(), BorderLayout.NORTH);
        add(buildCenterSection(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
    }

    private JPanel buildTopSection() {
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setOpaque(false);

        // Stat Cards
        JPanel stats = new JPanel(new GridLayout(1, 4, 10, 0));
        stats.setOpaque(false);
        JPanel c1 = UIConstants.createStatCard("0.00", "Total Waste In (kg)",
                UIConstants.ACCENT_RED);
        statTotalWaste = (JLabel) ((BorderLayout) c1.getLayout())
                .getLayoutComponent(BorderLayout.CENTER);
        stats.add(c1);
        JPanel c2 = UIConstants.createStatCard("0.00", "Fertilizer Out (units)",
                UIConstants.ACCENT_GREEN);
        statTotalFert = (JLabel) ((BorderLayout) c2.getLayout())
                .getLayoutComponent(BorderLayout.CENTER);
        stats.add(c2);
        JPanel c3 = UIConstants.createStatCard("0", "Batches Processed",
                UIConstants.ACCENT_BLUE);
        statBatches = (JLabel) ((BorderLayout) c3.getLayout())
                .getLayoutComponent(BorderLayout.CENTER);
        stats.add(c3);
        JPanel c4 = UIConstants.createStatCard("0.30", "Conversion Ratio",
                UIConstants.ACCENT_PURPLE);
        statRatio = (JLabel) ((BorderLayout) c4.getLayout())
                .getLayoutComponent(BorderLayout.CENTER);
        stats.add(c4);
        top.add(stats, BorderLayout.NORTH);

        // Input Form
        JPanel form = UIConstants.createCard();
        form.setLayout(new GridBagLayout());
        form.setBorder(UIConstants.createThemedTitledBorder(
                "Composting Simulation", UIConstants.ACCENT_PURPLE));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 10, 8, 10);
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx = 0; g.gridy = 0;
        form.add(label("Inedible Waste (kg):"), g);
        g.gridx = 1; g.weightx = 1;
        tfWasteInput = new JTextField(12);
        tfWasteInput.setFont(UIConstants.FONT_BODY);
        form.add(tfWasteInput, g);

        g.gridx = 2; g.weightx = 0;
        form.add(label("Conversion Ratio:"), g);
        g.gridx = 3; g.weightx = 1;
        tfRatio = new JTextField("0.3", 8);
        tfRatio.setFont(UIConstants.FONT_BODY);
        form.add(tfRatio, g);

        g.gridx = 4; g.weightx = 0;
        JButton btnProcess = UIConstants.createStyledButton(
                "Start Composting", UIConstants.ACCENT_PURPLE);
        btnProcess.addActionListener(e -> handleCompost());
        form.add(btnProcess, g);

        // Output row
        g.gridx = 0; g.gridy = 1; g.gridwidth = 2;
        lblOutputUnits = new JLabel("Fertilizer Output: --");
        lblOutputUnits.setFont(UIConstants.FONT_BODY_BOLD);
        lblOutputUnits.setForeground(UIConstants.ACCENT_GREEN);
        form.add(lblOutputUnits, g);

        g.gridx = 2; g.gridwidth = 3;
        pbProgress = new JProgressBar(0, 100);
        pbProgress.setStringPainted(true);
        pbProgress.setString("Ready to compost");
        pbProgress.setForeground(UIConstants.ACCENT_PURPLE);
        pbProgress.setBackground(new Color(230, 230, 240));
        pbProgress.setPreferredSize(new Dimension(0, 24));
        form.add(pbProgress, g);

        top.add(form, BorderLayout.CENTER);
        return top;
    }

    private JPanel buildCenterSection() {
        JPanel tc = UIConstants.createCard();
        tc.setLayout(new BorderLayout());
        JLabel tl = new JLabel("  Composting Batch History");
        tl.setFont(UIConstants.FONT_HEADING);
        tl.setForeground(UIConstants.ACCENT_PURPLE);
        tc.add(tl, BorderLayout.NORTH);

        String[] cols = {"Batch #", "Input Waste (kg)", "Ratio",
                "Fertilizer (units)", "Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UIConstants.styleTable(table);
        table.getTableHeader().setBackground(UIConstants.ACCENT_PURPLE);
        tc.add(new JScrollPane(table), BorderLayout.CENTER);
        return tc;
    }

    private JLabel buildStatusBar() {
        lblStatus = new JLabel("  Enter inedible waste quantity to start composting.");
        lblStatus.setFont(UIConstants.FONT_SMALL_ITALIC);
        lblStatus.setForeground(UIConstants.TEXT_SECONDARY);
        return lblStatus;
    }

    private void handleCompost() {
        try {
            double waste = Double.parseDouble(tfWasteInput.getText().trim());
            double ratio = Double.parseDouble(tfRatio.getText().trim());
            if (waste <= 0 || ratio <= 0) {
                setStatus("Enter positive values.", UIConstants.ACCENT_RED);
                return;
            }
            compostService.setConversionRatio(ratio);
            CompostBatch batch = compostService.processWaste(waste,
                    LocalDate.now().toString());
            if (batch == null) return;

            // Animate progress bar
            pbProgress.setValue(0);
            pbProgress.setString("Composting...");
            final int[] progress = {0};
            if (animTimer != null && animTimer.isRunning()) animTimer.stop();
            animTimer = new Timer(30, null);
            animTimer.addActionListener(ev -> {
                progress[0] += 2;
                pbProgress.setValue(Math.min(progress[0], 100));
                if (progress[0] >= 100) {
                    animTimer.stop();
                    pbProgress.setString("Complete!");
                    finishCompost(batch);
                }
            });
            animTimer.start();

        } catch (NumberFormatException ex) {
            setStatus("Please enter valid numbers.", UIConstants.ACCENT_RED);
        }
    }

    private void finishCompost(CompostBatch batch) {
        lblOutputUnits.setText(String.format(
                "Fertilizer Output: %.2f units (from %.2f kg waste)",
                batch.getOutputFertilizerUnits(), batch.getInputWasteKg()));
        tableModel.addRow(new Object[]{
            batch.getBatchId(),
            String.format("%.2f", batch.getInputWasteKg()),
            batch.getConversionRatio(),
            String.format("%.2f", batch.getOutputFertilizerUnits()),
            batch.getDate()
        });
        statTotalWaste.setText(String.format("%.2f",
                compostService.getTotalWasteProcessed()));
        statTotalFert.setText(String.format("%.2f",
                compostService.getTotalFertilizerProduced()));
        statBatches.setText(String.valueOf(compostService.getTotalBatches()));
        statRatio.setText(String.valueOf(compostService.getConversionRatio()));
        setStatus(String.format("Batch #%d complete: %.2f kg -> %.2f fertilizer units",
                batch.getBatchId(), batch.getInputWasteKg(),
                batch.getOutputFertilizerUnits()), UIConstants.ACCENT_GREEN);
        tfWasteInput.setText("");
    }

    private void setStatus(String msg, Color c) {
        lblStatus.setText("  " + msg);
        lblStatus.setForeground(c);
    }

    private JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setFont(UIConstants.FONT_BODY);
        return l;
    }
}
