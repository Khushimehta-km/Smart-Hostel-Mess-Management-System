package com.hostel.foodwaste.services;

import com.hostel.foodwaste.models.SpecialMealRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class: SpecialMealService
 * Manages special meal requests using ArrayList.
 */
public class SpecialMealService {
    private List<SpecialMealRequest> requests;
    private int nextRequestId;

    public SpecialMealService() {
        this.requests = new ArrayList<>();
        this.nextRequestId = 1;
    }

    public SpecialMealRequest addRequest(String studentId, String studentName, String reason, 
                                         String mealType, boolean doctorRecommended, String date) {
        SpecialMealRequest request = new SpecialMealRequest(
            nextRequestId++, studentId, studentName, reason, mealType, "Requested", doctorRecommended, date
        );
        requests.add(request);
        return request;
    }

    public boolean updateStatus(int requestId, String newStatus) {
        for (SpecialMealRequest r : requests) {
            if (r.getRequestId() == requestId) {
                r.setStatus(newStatus);
                return true;
            }
        }
        return false;
    }

    public boolean removeRequest(int requestId) {
        return requests.removeIf(r -> r.getRequestId() == requestId);
    }

    public List<SpecialMealRequest> getAllRequests() {
        return new ArrayList<>(requests);
    }

    public Map<String, Integer> getMealTypeCounts() {
        Map<String, Integer> counts = new HashMap<>();
        String[] types = {"Khichdi", "Daliya", "Oats", "Cornflakes"};
        for (String type : types) {
            counts.put(type, 0);
        }
        for (SpecialMealRequest r : requests) {
            counts.put(r.getMealType(), counts.getOrDefault(r.getMealType(), 0) + 1);
        }
        return counts;
    }

    public int getTotalRequests() {
        return requests.size();
    }
}
