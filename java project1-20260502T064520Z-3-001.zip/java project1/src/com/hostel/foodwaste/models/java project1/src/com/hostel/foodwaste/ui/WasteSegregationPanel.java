package com.hostel.foodwaste.ui;

import javax.swing.*;
import java.awt.*;

/**
 * WasteSegregationPanel — Classify leftover food into edible/inedible waste.
 * Color-coded panels and a visual ratio bar.
 */
public class WasteSegregationPanel extends JPanel {

    private JTextField tfTotalWaste;
    private JSlider sliderEdible;
    private JLabel lblEdibleQty, lblInedibleQty, lblEdiblePct, lblInediblePct;
    private JPanel edibleCard, inedibleCard;
    private RatioBar ratioBar;
    private JLabel lblStatus;

    // Shared state accessible by other panels
    private double lastEdibleKg = 0;
    private double lastInedibleKg = 0;

    public WasteSegregationPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UIConstants.BG_MAIN);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        add(buildInputSection(), BorderLayout.NORTH);
        add(buildResultSection(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
    }

    private JPanel buildInputSection() {
        JPanel card = UIConstants.createCard();
        card.setLayout(new GridBagLayout());
        card.setBorder(UIConstants.createThemedTitledBorder(
                "Waste Segregation Input", UIConstants.PRIMARY));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 10, 8, 10);
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx = 0;
        g.gridy = 0;
        JLabel lbl = new JLabel("Total Leftover Food (kg):");
        lbl.setFont(UIConstants.FONT_BODY);
        card.add(lbl, g);

        g.gridx = 1;
        g.weightx = 1;
        tfTotalWaste = new JTextField(12);
        tfTotalWaste.setFont(UIConstants.FONT_BODY);
        card.add(tfTotalWaste, g);

        g.gridx = 2;
        g.weightx = 0;
        JLabel lbl2 = new JLabel("Edible %:");
        lbl2.setFont(UIConstants.FONT_BODY);
        card.add(lbl2, g);

        g.gridx = 3;
        g.weightx = 1;
        sliderEdible = new JSlider(0, 100, 60);
        sliderEdible.setMajorTickSpacing(20);
        sliderEdible.setMinorTickSpacing(5);
        sliderEdible.setPaintTicks(true);
        sliderEdible.setPaintLabels(true);
        sliderEdible.setFont(UIConstants.FONT_SMALL);
        sliderEdible.setBackground(UIConstants.BG_CARD);
        card.add(sliderEdible, g);

        g.gridx = 4;
        g.weightx = 0;
        JButton btnClassify = UIConstants.createStyledButton(
                "Classify Waste", UIConstants.BTN_INFO);
        btnClassify.addActionListener(e -> handleClassify());
        card.add(btnClassify, g);

        return card;
    }

    private JPanel buildResultSection() {
        JPanel center = new JPanel(new BorderLayout(10, 10));
        center.setOpaque(false);

        // Two result cards side by side
        JPanel cards = new JPanel(new GridLayout(1, 2, 15, 0));
        cards.setOpaque(false);

        // Edible Waste Card (green)
        edibleCard = new JPanel(new BorderLayout(5, 5));
        edibleCard.setBackground(new Color(232, 245, 233));
        edibleCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIConstants.ACCENT_GREEN, 2),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)));

        JLabel edibleIcon = new JLabel("\u2705  EDIBLE WASTE", JLabel.CENTER);
        edibleIcon.setFont(UIConstants.FONT_SUBTITLE);
        edibleIcon.setForeground(UIConstants.ACCENT_GREEN);
        edibleCard.add(edibleIcon, BorderLayout.NORTH);

        lblEdibleQty = new JLabel("0.00 kg", JLabel.CENTER);
        lblEdibleQty.setFont(UIConstants.FONT_CARD_VALUE);
        lblEdibleQty.setForeground(UIConstants.ACCENT_GREEN);
        edibleCard.add(lblEdibleQty, BorderLayout.CENTER);

        lblEdiblePct = new JLabel("0% of total waste", JLabel.CENTER);
        lblEdiblePct.setFont(UIConstants.FONT_BODY);
        lblEdiblePct.setForeground(UIConstants.TEXT_SECONDARY);
        edibleCard.add(lblEdiblePct, BorderLayout.SOUTH);
        cards.add(edibleCard);

        // Inedible Waste Card (red)
        inedibleCard = new JPanel(new BorderLayout(5, 5));
        inedibleCard.setBackground(new Color(253, 237, 237));
        inedibleCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIConstants.ACCENT_RED, 2),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)));

        JLabel inedibleIcon = new JLabel("\u274C  INEDIBLE WASTE", JLabel.CENTER);
        inedibleIcon.setFont(UIConstants.FONT_SUBTITLE);
        inedibleIcon.setForeground(UIConstants.ACCENT_RED);
        inedibleCard.add(inedibleIcon, BorderLayout.NORTH);

        lblInedibleQty = new JLabel("0.00 kg", JLabel.CENTER);
        lblInedibleQty.setFont(UIConstants.FONT_CARD_VALUE);
        lblInedibleQty.setForeground(UIConstants.ACCENT_RED);
        inedibleCard.add(lblInedibleQty, BorderLayout.CENTER);

        lblInediblePct = new JLabel("0% of total waste", JLabel.CENTER);
        lblInediblePct.setFont(UIConstants.FONT_BODY);
        lblInediblePct.setForeground(UIConstants.TEXT_SECONDARY);
        inedibleCard.add(lblInediblePct, BorderLayout.SOUTH);
        cards.add(inedibleCard);

        center.add(cards, BorderLayout.CENTER);

        // Ratio Bar
        JPanel barCard = UIConstants.createCard();
        barCard.setLayout(new BorderLayout(5, 5));
        JLabel barTitle = new JLabel("  Edible vs Inedible Ratio");
        barTitle.setFont(UIConstants.FONT_HEADING);
        barTitle.setForeground(UIConstants.PRIMARY);
        barCard.add(barTitle, BorderLayout.NORTH);
        ratioBar = new RatioBar();
        ratioBar.setPreferredSize(new Dimension(0, 40));
        barCard.add(ratioBar, BorderLayout.CENTER);

        // Info panel
        JPanel info = new JPanel(new GridLayout(1, 2, 10, 0));
        info.setOpaque(false);
        JLabel infoEdible = new JLabel(
                "  Edible waste can be donated to NGOs if above threshold.");
        infoEdible.setFont(UIConstants.FONT_SMALL_ITALIC);
        infoEdible.setForeground(UIConstants.ACCENT_GREEN);
        info.add(infoEdible);
        JLabel infoInedible = new JLabel(
                "  Inedible waste can be sent for composting.");
        infoInedible.setFont(UIConstants.FONT_SMALL_ITALIC);
        infoInedible.setForeground(UIConstants.ACCENT_RED);
        info.add(infoInedible);
        barCard.add(info, BorderLayout.SOUTH);

        center.add(barCard, BorderLayout.SOUTH);
        return center;
    }

    private JLabel buildStatusBar() {
        lblStatus = new JLabel("  Enter total leftover food and adjust the edible slider.");
        lblStatus.setFont(UIConstants.FONT_SMALL_ITALIC);
        lblStatus.setForeground(UIConstants.TEXT_SECONDARY);
        return lblStatus;
    }

    private void handleClassify() {
        try {
            double total = Double.parseDouble(tfTotalWaste.getText().trim());
            if (total <= 0) {
                setStatus("Enter a positive quantity.", UIConstants.ACCENT_RED);
                return;
            }

            int ediblePct = sliderEdible.getValue();
            double edible = total * ediblePct / 100.0;
            double inedible = total - edible;

            lastEdibleKg = edible;
            lastInedibleKg = inedible;

            // UI update
            lblEdibleQty.setText(String.format("%.2f kg", edible));
            lblEdiblePct.setText(ediblePct + "% of total waste");
            lblInedibleQty.setText(String.format("%.2f kg", inedible));
            lblInediblePct.setText((100 - ediblePct) + "% of total waste");
            ratioBar.setRatio(ediblePct);

            // 🔥 NEW PART: SAVE TO DATABASE
            com.hostel.foodwaste.services.DataRepository repo = new com.hostel.foodwaste.services.DataRepository();

            repo.saveWasteData("Mixed Waste", (int) total);

            setStatus(String.format(
                    "Saved to DB: %.2f kg total waste (%.2f edible + %.2f inedible)",
                    total, edible, inedible), UIConstants.ACCENT_GREEN);

        } catch (NumberFormatException ex) {
            setStatus("Please enter a valid number.", UIConstants.ACCENT_RED);
        }
    }

    private void setStatus(String msg, Color c) {
        lblStatus.setText("  " + msg);
        lblStatus.setForeground(c);
    }

    public double getLastEdibleKg() {
        return lastEdibleKg;
    }

    public double getLastInedibleKg() {
        return lastInedibleKg;
    }

    // Custom ratio bar component
    private static class RatioBar extends JPanel {
        private int ediblePct = 0;

        RatioBar() {
            setBackground(new Color(230, 230, 230));
        }

        void setRatio(int pct) {
            this.ediblePct = pct;
            repaint();
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            int edibleW = (int) (w * ediblePct / 100.0);
            // Edible portion (green)
            g2.setColor(UIConstants.ACCENT_GREEN);
            g2.fillRoundRect(0, 0, edibleW, h, 8, 8);
            // Inedible portion (red)
            g2.setColor(UIConstants.ACCENT_RED);
            g2.fillRoundRect(edibleW, 0, w - edibleW, h, 8, 8);
            // Labels
            g2.setFont(UIConstants.FONT_BODY_BOLD);
            g2.setColor(Color.WHITE);
            if (edibleW > 60)
                g2.drawString("Edible " + ediblePct + "%", 10, h / 2 + 5);
            if (w - edibleW > 80)
                g2.drawString("Inedible " + (100 - ediblePct) + "%",
                        edibleW + 10, h / 2 + 5);
        }
    }
}
