package com.hostel.foodwaste.utils;

import com.hostel.foodwaste.utils.exceptions.InvalidWasteException;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class: WasteFileHandler
 * Handles saving and reading food waste records to/from a text file.
 */
public class WasteFileHandler {

    private String filePath;
    private static final String SEPARATOR = ",";

    public WasteFileHandler() {
        this("waste_records.txt");
    }

    public WasteFileHandler(String filePath) {
        this.filePath = filePath;
    }

    public void saveRecord(String foodName, double quantityKg,
                           String reason, String date)
            throws InvalidWasteException {
        validateRecord(foodName, quantityKg, reason);
        String line = foodName + SEPARATOR + quantityKg + SEPARATOR
                    + reason  + SEPARATOR + date;

        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            fw = new FileWriter(filePath, true);
            bw = new BufferedWriter(fw);
            bw.write(line);
            bw.newLine();
            System.out.println("[FileHandler] Saved -> " + line);
        } catch (IOException e) {
            System.out.println("[FileHandler] ERROR writing to file: " + e.getMessage());
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
                System.out.println("[FileHandler] ERROR closing writer: " + e.getMessage());
            }
        }
    }

    public void saveRecord(String foodName, double quantityKg,
                           String reason, String date, boolean appendMode)
            throws InvalidWasteException {
        validateRecord(foodName, quantityKg, reason);
        String line = foodName + SEPARATOR + quantityKg + SEPARATOR
                    + reason  + SEPARATOR + date;

        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            fw = new FileWriter(filePath, appendMode);
            bw = new BufferedWriter(fw);
            bw.write(line);
            bw.newLine();
            System.out.println("[FileHandler] Saved (" + (appendMode ? "append" : "overwrite")
                               + ") -> " + line);
        } catch (IOException e) {
            System.out.println("[FileHandler] ERROR: " + e.getMessage());
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
                System.out.println("[FileHandler] ERROR closing writer: " + e.getMessage());
            }
        }
    }

    public void saveAllRecords(List<String> records) throws InvalidWasteException {
        if (records == null || records.isEmpty()) {
            throw new InvalidWasteException("Record list is null or empty.", "records");
        }
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            fw = new FileWriter(filePath, false);
            bw = new BufferedWriter(fw);
            for (String record : records) {
                bw.write(record);
                bw.newLine();
            }
            System.out.println("[FileHandler] Saved " + records.size() + " records to: " + filePath);
        } catch (IOException e) {
            System.out.println("[FileHandler] ERROR writing records: " + e.getMessage());
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
                System.out.println("[FileHandler] ERROR closing writer: " + e.getMessage());
            }
        }
    }

    public List<String> readAllRecords() {
        List<String> records = new ArrayList<>();
        FileReader fr = null;
        BufferedReader br = null;
        try {
            fr = new FileReader(filePath);
            br = new BufferedReader(fr);
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    records.add(line.trim());
                }
            }
            System.out.println("[FileHandler] Read " + records.size() + " record(s) from: " + filePath);
        } catch (IOException e) {
            System.out.println("[FileHandler] Could not read file: " + e.getMessage());
        } finally {
            try {
                if (br != null) br.close();
                if (fr != null) fr.close();
            } catch (IOException e) {
                System.out.println("[FileHandler] ERROR closing reader: " + e.getMessage());
            }
        }
        return records;
    }

    public void displayFileContents() {
        List<String> records = readAllRecords();
        System.out.println("=== Waste Records File: " + filePath + " ===");
        if (records.isEmpty()) {
            System.out.println("  (File is empty or does not exist)");
            return;
        }
        System.out.println("  No. | Food Name  | Qty (kg) | Reason       | Date");
        System.out.println("  ----|------------|----------|--------------|------------");
        int lineNum = 1;
        for (String record : records) {
            String[] parts = record.split(SEPARATOR);
            if (parts.length == 4) {
                System.out.printf("  %-3d | %-10s | %-8s | %-12s | %s%n",
                        lineNum++, parts[0], parts[1], parts[2], parts[3]);
            } else {
                System.out.println("  [Skipped malformed line: " + record + "]");
            }
        }
    }

    private void validateRecord(String foodName, double quantityKg, String reason)
            throws InvalidWasteException {
        if (foodName == null || foodName.trim().isEmpty()) {
            throw new InvalidWasteException("Food name cannot be null or empty.", "foodName");
        }
        if (quantityKg <= 0) {
            throw new InvalidWasteException(
                "Quantity must be greater than 0. Got: " + quantityKg, "quantityKg");
        }
        if (reason == null || reason.trim().isEmpty()) {
            throw new InvalidWasteException("Reason cannot be null or empty.", "reason");
        }
    }

    public String getFilePath()              { return filePath; }
    public void   setFilePath(String path)   { this.filePath = path; }
}
