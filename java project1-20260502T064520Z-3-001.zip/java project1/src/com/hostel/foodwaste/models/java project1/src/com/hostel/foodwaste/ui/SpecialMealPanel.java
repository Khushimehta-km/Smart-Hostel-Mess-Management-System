package com.hostel.foodwaste.ui;

import com.hostel.foodwaste.models.SpecialMealRequest;
import com.hostel.foodwaste.services.DataRepository;
import com.hostel.foodwaste.services.SpecialMealService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * SpecialMealPanel — Module for sick students to request special light meals.
 * Includes Impact Analysis: sick student count and meal reduction.
 */
public class SpecialMealPanel extends JPanel {

    private final SpecialMealService service = new SpecialMealService();
    private JTextField tfStudentId, tfStudentName, tfReason, tfDate;
    private JComboBox<String> cbMealType;
    private JCheckBox chkDoctorRecommended;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblStatus;
    
    // Impact Analysis labels
    private JLabel lblTotalSick, lblReduction, lblExtraPrep;

    public SpecialMealPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UIConstants.BG_MAIN);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        add(buildImpactHeader(), BorderLayout.NORTH);
        add(buildCenterSection(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
        
        refreshData();
    }

    private JPanel buildImpactHeader() {
        JPanel header = new JPanel(new GridLayout(1, 3, 10, 0));
        header.setOpaque(false);

        header.add(UIConstants.createStatCard("0", "Total Sick Students", UIConstants.ACCENT_RED));
        lblTotalSick = (JLabel)((BorderLayout)((JPanel)header.getComponent(0)).getLayout()).getLayoutComponent(BorderLayout.CENTER);

        header.add(UIConstants.createStatCard("0", "Normal Meal Reduction", UIConstants.ACCENT_ORANGE));
        lblReduction = (JLabel)((BorderLayout)((JPanel)header.getComponent(1)).getLayout()).getLayoutComponent(BorderLayout.CENTER);

        header.add(UIConstants.createStatCard("0 kg", "Additional Special Prep", UIConstants.ACCENT_BLUE));
        lblExtraPrep = (JLabel)((BorderLayout)((JPanel)header.getComponent(2)).getLayout()).getLayoutComponent(BorderLayout.CENTER);

        return header;
    }

    private JPanel buildCenterSection() {
        JPanel container = new JPanel(new BorderLayout(0, 10));
        container.setOpaque(false);

        // Request Form
        JPanel form = UIConstants.createCard();
        form.setLayout(new GridBagLayout());
        form.setBorder(UIConstants.createThemedTitledBorder("Request Special Meal", UIConstants.PRIMARY));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx=0; g.gridy=0; form.add(label("Student ID:"), g);
        g.gridx=1; g.weightx=1; tfStudentId = field(12); form.add(tfStudentId, g);
        g.gridx=2; g.weightx=0; form.add(label("Student Name:"), g);
        g.gridx=3; g.weightx=1; tfStudentName = field(12); form.add(tfStudentName, g);

        g.gridx=0; g.gridy=1; g.weightx=0; form.add(label("Reason:"), g);
        g.gridx=1; g.weightx=1; tfReason = field(12); form.add(tfReason, g);
        g.gridx=2; g.weightx=0; form.add(label("Meal Type:"), g);
        g.gridx=3; g.weightx=1;
        cbMealType = new JComboBox<>(new String[]{"Khichdi", "Daliya", "Oats", "Cornflakes"});
        cbMealType.setFont(UIConstants.FONT_BODY); form.add(cbMealType, g);

        g.gridx=0; g.gridy=2; g.weightx=0; form.add(label("Date:"), g);
        g.gridx=1; g.weightx=1; tfDate = new JTextField(LocalDate.now().toString(), 12);
        tfDate.setFont(UIConstants.FONT_BODY); form.add(tfDate, g);
        
        g.gridx=2; g.weightx=0; 
        chkDoctorRecommended = new JCheckBox("Doc Rec");
        chkDoctorRecommended.setFont(UIConstants.FONT_BODY);
        chkDoctorRecommended.setOpaque(false);
        form.add(chkDoctorRecommended, g);

        g.gridx=3;
        JButton btnAdd = UIConstants.createStyledButton("Submit Request", UIConstants.BTN_SUCCESS);
        btnAdd.addActionListener(e -> handleSubmit());
        form.add(btnAdd, g);

        container.add(form, BorderLayout.NORTH);

        // Table
        JPanel tc = UIConstants.createCard();
        tc.setLayout(new BorderLayout());
        tc.setBorder(UIConstants.createThemedTitledBorder("Meal Requests Log", UIConstants.PRIMARY));
        
        String[] cols = {"ID", "Student", "Meal", "Doc Rec", "Status", "Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
            public Class<?> getColumnClass(int c) {
                if (c == 3) return Boolean.class;
                return super.getColumnClass(c);
            }
        };
        table = new JTable(tableModel);
        UIConstants.styleTable(table);
        tc.add(new JScrollPane(table), BorderLayout.CENTER);
        
        container.add(tc, BorderLayout.CENTER);
        return container;
    }

    private JLabel buildStatusBar() {
        lblStatus = new JLabel("  Ready. Sick students can request light meals here.");
        lblStatus.setFont(UIConstants.FONT_SMALL_ITALIC);
        lblStatus.setForeground(UIConstants.TEXT_SECONDARY);
        return lblStatus;
    }

    private void handleSubmit() {
        String sid = tfStudentId.getText().trim();
        String sname = tfStudentName.getText().trim();
        String reason = tfReason.getText().trim();
        String meal = (String) cbMealType.getSelectedItem();
        String date = tfDate.getText().trim();
        boolean docRec = chkDoctorRecommended.isSelected();

        if (sid.isEmpty() || sname.isEmpty() || reason.isEmpty()) {
            setStatus("Please fill in all fields.", UIConstants.ACCENT_RED);
            return;
        }

        SpecialMealRequest r = new SpecialMealRequest(
                (int)(Math.random()*1000), sid, sname, reason, meal, "Requested", docRec, date
        );
        DataRepository.getInstance().addSpecialMealRequest(r);
        
        refreshData();
        setStatus("Request submitted for " + sname, UIConstants.ACCENT_GREEN);
        handleClear();
    }

    private void handleClear() {
        tfStudentId.setText("");
        tfStudentName.setText("");
        tfReason.setText("");
        cbMealType.setSelectedIndex(0);
        tfDate.setText(LocalDate.now().toString());
        chkDoctorRecommended.setSelected(false);
    }

    private void refreshData() {
        String date = tfDate.getText().trim();
        List<SpecialMealRequest> requests = DataRepository.getInstance().getSpecialMealRequests();
        
        tableModel.setRowCount(0);
        for (SpecialMealRequest r : requests) {
            tableModel.addRow(new Object[]{r.getRequestId(), r.getStudentName(), r.getMealType(), r.isDoctorRecommended(), r.getStatus(), r.getRequestDate()});
        }

        // Impact analysis for today
        List<SpecialMealRequest> today = DataRepository.getInstance().getSpecialMealsByDate(LocalDate.now().toString());
        lblTotalSick.setText(String.valueOf(today.size()));
        lblReduction.setText(String.valueOf(today.size()));
        lblExtraPrep.setText(String.format("%.1f kg", today.size() * 0.4));
    }

    private void setStatus(String msg, Color c) {
        lblStatus.setText("  " + msg);
        lblStatus.setForeground(c);
    }

    private JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setFont(UIConstants.FONT_BODY);
        return l;
    }

    private JTextField field(int cols) {
        JTextField f = new JTextField(cols);
        f.setFont(UIConstants.FONT_BODY);
        return f;
    }
}
