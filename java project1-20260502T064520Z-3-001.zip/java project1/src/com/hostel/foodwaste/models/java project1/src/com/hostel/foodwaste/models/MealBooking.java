package com.hostel.foodwaste.models;

/**
 * Class: MealBooking
 * Represents a single meal booking by a student.
 *
 * Concepts used:
 *   - Encapsulation (private fields, public getters/setters)
 *   - Constructor chaining with this()
 *   - Method overloading (toString variants)
 */
public class MealBooking {

    // ── Fields ────────────────────────────────────────────────────────────
    private int     bookingId;
    private String  studentId;
    private String  studentName;
    private String  roomNumber;
    private String  mealType;       // Breakfast, Lunch, Snacks, Dinner
    private String  date;
    private boolean confirmed;

    // ── Default Constructor ───────────────────────────────────────────────
    public MealBooking() {
        this(0, "N/A", "Guest", "N/A", "Lunch", "N/A", false);
    }

    // ── Parameterized Constructor ─────────────────────────────────────────
    public MealBooking(int bookingId, String studentId, String studentName,
                       String roomNumber, String mealType, String date, boolean confirmed) {
        this.bookingId   = bookingId;
        this.studentId   = studentId;
        this.studentName = studentName;
        this.roomNumber  = roomNumber;
        this.mealType    = mealType;
        this.date        = date;
        this.confirmed   = confirmed;
    }

    // ── Convenience Constructor (auto-confirmed) ──────────────────────────
    public MealBooking(int bookingId, String studentId, String studentName,
                       String roomNumber, String mealType, String date) {
        this(bookingId, studentId, studentName, roomNumber, mealType, date, true);
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public int     getBookingId()   { return bookingId; }
    public String  getStudentId()   { return studentId; }
    public String  getStudentName() { return studentName; }
    public String  getRoomNumber()  { return roomNumber; }
    public String  getMealType()    { return mealType; }
    public String  getDate()        { return date; }
    public boolean isConfirmed()    { return confirmed; }

    // ── Setters ───────────────────────────────────────────────────────────
    public void setBookingId(int bookingId)       { this.bookingId   = bookingId; }
    public void setStudentId(String studentId)    { this.studentId   = studentId; }
    public void setStudentName(String studentName){ this.studentName = studentName; }
    public void setRoomNumber(String roomNumber)  { this.roomNumber  = roomNumber; }
    public void setMealType(String mealType)      { this.mealType    = mealType; }
    public void setDate(String date)              { this.date        = date; }
    public void setConfirmed(boolean confirmed)   { this.confirmed   = confirmed; }

    @Override
    public String toString() {
        return "Booking#" + bookingId +
               " | " + studentName + " (" + studentId + ")" +
               " | Room: " + roomNumber +
               " | " + mealType +
               " | Date: " + date +
               " | " + (confirmed ? "CONFIRMED" : "PENDING");
    }
}
