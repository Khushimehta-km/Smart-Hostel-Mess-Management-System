package com.hostel.foodwaste.utils;

import java.util.List;

/**
 * Interface: WasteOperations
 * Contract for any waste-management implementation.
 */
public interface WasteOperations {
    void logWaste(com.hostel.foodwaste.models.Food food, double quantityKg, String reason);
    void logWaste(com.hostel.foodwaste.models.Food food, double quantityKg, String reason, String date);
    void removeWasteRecord(int recordId);
    List<String> getWasteSummary();
}
